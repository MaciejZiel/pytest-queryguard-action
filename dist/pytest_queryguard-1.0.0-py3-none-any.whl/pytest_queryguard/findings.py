from __future__ import annotations

from dataclasses import dataclass, field

# Finding kinds. They are part of the identity of a finding, so they never change.
KIND_RELATIONSHIP = "relationship-load"
KIND_REPEAT = "repeated-statement"
KIND_MISSING_INDEX = "missing-index"
KIND_COLUMN_LOAD = "column-load"
KIND_WRITE_LOOP = "write-loop"
KIND_UNUSED_EAGER_LOAD = "unused-eager-load"
KIND_CARTESIAN_LOAD = "cartesian-load"
KIND_UNUSED_COLUMNS = "unused-columns"

SEVERITY_ERROR = "error"

# Callers of a finding's location as (file, line, function), innermost first.
Stack = tuple[tuple[str, int, str], ...]

DOCS_URL = "https://maciejziel.github.io/pytest-queryguard/"
# The documentation section of each kind. The anchors are pinned by a test of
# the built site (tests/test_docs_site.py), so a renamed heading fails there.
_KIND_DOCS = {
    KIND_RELATIONSHIP: "how-detection-works.html#relationship-load",
    KIND_REPEAT: "how-detection-works.html#repeated-statement",
    KIND_COLUMN_LOAD: "how-detection-works.html#column-load",
    KIND_WRITE_LOOP: "how-detection-works.html#write-loop",
    KIND_MISSING_INDEX: "how-detection-works.html#missing-index",
    KIND_UNUSED_EAGER_LOAD: "unused-eager-load.html",
    KIND_CARTESIAN_LOAD: "how-detection-works.html#cartesian-load",
    KIND_UNUSED_COLUMNS: "unused-columns.html",
}


def docs_url(kind: str) -> str:
    """The page and section that explain a finding kind and how to fix it."""
    return DOCS_URL + _KIND_DOCS.get(kind, "when-a-test-fails.html")


@dataclass(frozen=True, slots=True, kw_only=True)
class IndexAdvice:
    """The index the advisor suggests for a ``missing-index`` finding.

    ``create_index`` is the statement and ``alembic`` the matching
    ``op.create_index`` call; both are None when no new index is suggested,
    and ``skipped`` says why (an index for these columns exists but is
    unusable). ``verified`` is None when hypopg did not check the suggestion,
    True when it says the planner would use the index and False when it would
    not. The costs are the planner's estimates for the whole statement, with
    sequential scans allowed, before and after adding the index.
    """

    create_index: str | None = None
    alembic: str | None = None
    columns: tuple[str, ...] = ()
    where: str | None = None
    skipped: str | None = None
    verified: bool | None = None
    cost_before: float | None = None
    cost_after: float | None = None
    size_bytes: int | None = None
    verification_error: str | None = None


@dataclass(frozen=True, slots=True, order=True)
class Insertion:
    """Text to insert into a source file, before the character at a position.

    ``line`` counts from 1; ``column`` counts characters from 0 and
    ``utf16_column`` the same position in UTF-16 code units, as SARIF counts.
    """

    line: int
    column: int
    utf16_column: int
    text: str


@dataclass(frozen=True, slots=True, kw_only=True)
class SourceFix:
    """A change to one source file that fixes a finding (see fixpatch.py).

    ``file`` is relative to pytest's rootdir, with forward slashes; ``diff``
    is the unified diff of this change alone, which ``git apply`` accepts
    from the rootdir.
    """

    file: str
    insertions: tuple[Insertion, ...]
    description: str
    diff: str


@dataclass(frozen=True, slots=True, kw_only=True)
class Finding:
    """One problem a detector found, with its report text already rendered.

    ``kind`` and ``label`` say what was found: for ``relationship-load`` the
    relationship (``Order.customer``), for ``repeated-statement`` the
    normalized statement, for ``column-load`` the class and the deferred
    attributes (``Child.blob``) or its cause (``Parent (expired)``), for ``write-loop`` the normalized
    INSERT, UPDATE or DELETE, for ``unused-eager-load`` the relationship
    (``Order.customer``), for ``unused-columns`` the class (``Customer``),
    for ``missing-index`` the table. ``file`` and
    ``function`` say where it first happened: ``file`` is relative to pytest's
    rootdir (in the in-application mode, to the current directory), with
    forward slashes, or as the interpreter reports it when the file is
    outside it; both are None when the call site is unknown.

    ``(kind, label, file, function)`` is the identity: it stays the same from
    run to run, whatever the line numbers and counts, and whatever directory
    the suite runs from. ``line`` and ``count`` are details of one run.

    ``pytest_queryguard.app`` exports this class as ``Finding``. Its public
    fields are ``kind``, ``label``, ``file``, ``function``, ``line``,
    ``count`` and ``message`` (docs/stability.md), and it may be built with
    those as keyword arguments. Every other field, and ``identity``, is
    internal; a new field needs a default, so that such a call keeps working.
    """

    kind: str
    label: str
    file: str | None
    function: str | None
    message: str
    severity: str = SEVERITY_ERROR
    line: int | None = None
    count: int = 1
    # Set when the same finding was merged over several tests (SARIF): how
    # many tests it came from, and the largest count in any one of them.
    # ``count`` is then the total. Not part of the identity.
    tests: int = 1
    peak: int | None = None
    # For ``missing-index`` findings, with the index advisor on; not part of
    # the identity.
    advice: IndexAdvice | None = None
    # For ``missing-index`` findings: (schema, table) as the plan names them,
    # which the label may leave out or quote; lets ignore patterns match any
    # spelling of the table. Not part of the identity.
    table: tuple[str | None, str] | None = field(default=None, compare=False)
    # The application frames that called the first location, innermost first,
    # as (file, line, function) with ``file`` shown like ``file`` above. Empty
    # when unknown or turned off (queryguard_stack_depth = 0). Not part of the
    # identity.
    stack: Stack = field(default=(), compare=False)
    # For ``relationship-load`` findings whose parent query line is certain:
    # the change that adds the loader option to it. Made only when a patch or
    # SARIF is asked for. Not part of the identity.
    fix: SourceFix | None = field(default=None, compare=False)
    # True when every statement of the finding ran in test code (a test
    # module, conftest.py, a factory or a helper under tests/), not in the
    # application; see queryguard_test_code. Not part of the identity.
    test_code: bool = field(default=False, compare=False)

    @property
    def identity(self) -> tuple[str, str, str | None, str | None]:
        return (self.kind, self.label, self.file, self.function)


def message_text(finding: Finding) -> str:
    """The finding's report text without the indent of the terminal report."""
    lines = [line.removeprefix("  ") for line in finding.message.splitlines()]
    return "\n".join(lines).strip() or finding.label
