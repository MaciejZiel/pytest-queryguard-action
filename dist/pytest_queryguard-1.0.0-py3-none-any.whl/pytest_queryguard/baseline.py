"""The baseline file: findings a project knows about and accepts for now.

A baseline lists the identities (``Finding.identity``: kind, label, file and
function) of findings that existed when it was written. A finding on the list
does not fail or warn; anything else is reported as usual. The file holds no
line numbers and no counts, so editing code above a finding or loading a few
more rows does not invalidate an entry.
"""

from __future__ import annotations

import difflib
import json
import re
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from .fileio import atomic_write_text
from .findings import Finding

SCHEMA_VERSION = 1

Identity = tuple[str, str, str | None, str | None]


class BaselineError(ValueError):
    """The baseline file cannot be used; the message says why."""


def _sort_key(identity: Identity) -> tuple[str, str, str, str, int, int]:
    kind, label, file, function = identity
    # None sorts before any string, and the order never depends on the run
    return (kind, label, file or "", function or "", file is None, function is None)


def sorted_identities(identities: Iterable[Identity]) -> list[Identity]:
    return sorted(set(identities), key=_sort_key)


def dumps(identities: Iterable[Identity]) -> str:
    """The file text for these identities: sorted, indented, ends with a newline."""
    entries = [
        {"kind": kind, "label": label, "file": file, "function": function}
        for kind, label, file, function in sorted_identities(identities)
    ]
    document = {"version": SCHEMA_VERSION, "findings": entries}
    text = json.dumps(document, indent=2, ensure_ascii=False) + "\n"
    try:
        text.encode("utf-8")
    except UnicodeEncodeError:
        pass
    else:
        return text
    # A path that is not valid UTF-8 reaches an identity as a lone surrogate
    # (surrogateescape), which UTF-8 cannot encode. \udcXX escapes are plain
    # ASCII and read back as the same string.
    return json.dumps(document, indent=2, ensure_ascii=True) + "\n"


def write(path: Path, identities: Iterable[Identity]) -> None:
    """Write the baseline atomically, with ``\\n`` line ends on every platform."""
    atomic_write_text(path, dumps(identities))


_ENTRY_KEYS = ("kind", "label", "file", "function")


def _check_misspelled_keys(entry: dict[Any, Any], where: str) -> None:
    """Reject an unknown key that looks like a missing identity key.

    Other unknown keys are ignored: a later release may add keys to an entry
    without a new version (docs/stability.md), and this one must still read
    the file. A misspelled ``file`` or ``function`` would otherwise be read as
    null, and the entry would quietly match nothing.
    """
    missing = [key for key in _ENTRY_KEYS if key not in entry]
    for key in sorted(str(k) for k in entry if k not in _ENTRY_KEYS):
        close = difflib.get_close_matches(key.lower(), missing, n=1, cutoff=0.75)
        if close:
            raise BaselineError(
                f"{where} has an unknown key {key!r}; did you mean {close[0]!r}?"
            )


def _entry_identity(entry: Any, index: int, path: Path) -> Identity:
    where = f"{path}: findings[{index}]"
    if not isinstance(entry, dict):
        raise BaselineError(f"{where} must be an object, got {entry!r}")
    _check_misspelled_keys(entry, where)
    for key in ("kind", "label"):
        if not isinstance(entry.get(key), str) or not entry[key]:
            raise BaselineError(f"{where}: {key!r} must be a non-empty string")
    for key in ("file", "function"):
        value = entry.get(key)
        if value is not None and not isinstance(value, str):
            raise BaselineError(f"{where}: {key!r} must be a string or null")
    return (entry["kind"], entry["label"], entry.get("file"), entry.get("function"))


# A baseline is four levels deep; the limit only has to stay far from the
# interpreter's own recursion limit, which differs per Python version and platform.
_MAX_NESTING = 100
_NESTING_TOKEN = re.compile(r'"(?:[^"\\]|\\.)*"|[\[{]|[\]}]', re.DOTALL)


def _too_deep(text: str) -> bool:
    """Whether arrays or objects nest past the limit, found without recursion."""
    depth = 0
    for match in _NESTING_TOKEN.finditer(text):
        token = match.group()
        if token in "[{":
            depth += 1
            if depth > _MAX_NESTING:
                return True
        elif token in "]}":
            depth -= 1
    return False


def parse(text: str, path: Path) -> frozenset[Identity]:
    """The identities in the file text; raise BaselineError when it is invalid."""
    if _too_deep(text):
        # checked first: json would recurse, and the RecursionError it ends in can
        # surface again later (as an unraisable exception) on some interpreters
        raise BaselineError(f"{path} is not a queryguard baseline (nested too deep)")
    try:
        document = json.loads(text)
    except ValueError as exc:
        raise BaselineError(f"{path} is not valid JSON: {exc}") from None
    except RecursionError:
        # json raises it, not ValueError, for arrays or objects nested too deep
        raise BaselineError(
            f"{path} is not a queryguard baseline (nested too deep)"
        ) from None
    if not isinstance(document, dict) or "version" not in document:
        raise BaselineError(
            f"{path} is not a queryguard baseline (no 'version' field); "
            "regenerate it with --queryguard-update-baseline"
        )
    version = document["version"]
    if version != SCHEMA_VERSION or isinstance(version, bool):
        raise BaselineError(
            f"{path} has version {version!r}, but this pytest-queryguard reads "
            f"version {SCHEMA_VERSION}; upgrade the plugin or regenerate the file "
            "with --queryguard-update-baseline"
        )
    entries = document.get("findings")
    if not isinstance(entries, list):
        raise BaselineError(f"{path}: 'findings' must be a list")
    return frozenset(_entry_identity(entry, i, path) for i, entry in enumerate(entries))


def load(path: Path) -> frozenset[Identity]:
    """Read the baseline file; raise BaselineError when it is missing or invalid."""
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        raise BaselineError(
            f"baseline file {path} does not exist; create it with "
            "--queryguard-update-baseline"
        ) from None
    except (OSError, UnicodeDecodeError) as exc:
        raise BaselineError(f"cannot read baseline file {path}: {exc}") from None
    return parse(text, path)


def split(
    findings: Iterable[Finding], baseline: frozenset[Identity]
) -> tuple[list[Finding], list[Finding]]:
    """(findings not in the baseline, findings in it)."""
    new: list[Finding] = []
    known: list[Finding] = []
    for finding in findings:
        (known if finding.identity in baseline else new).append(finding)
    return new, known
