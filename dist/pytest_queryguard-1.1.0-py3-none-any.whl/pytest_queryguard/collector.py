from __future__ import annotations

import sys
import threading
from collections.abc import Callable, Sequence
from contextvars import ContextVar, Token
from dataclasses import dataclass, field, replace

from . import callsite
from .blocks import IgnoreBlock, covers
from .blocks import current as current_blocks
from .callsite import Entry
from .events import (
    CallSite,
    CartesianLoadEvent,
    ColumnLoadEvent,
    RelationshipLoadEvent,
    ScanEvent,
    StatementEvent,
    query_line,
    read_key,
)
from .findings import KIND_RELATIONSHIP

# Without the GIL (free-threaded CPython) ``count += 1`` from several threads
# loses updates, so the add_* methods take a lock there. With the GIL the
# check below is the whole cost. The GIL can be switched on later (a C
# extension that needs it) but never off, so a build that starts without it
# keeps the lock, which is only ever redundant.
_FREE_THREADED = not getattr(sys, "_is_gil_enabled", lambda: True)()
_ALL = object()  # _report_site: the loads of every unit
# Most distinct entries a collector keeps (note_entry); a scope begun from
# lines first seen later counts with the scopes begun from shared lines, as
# all scopes did before.
MAX_ENTRIES = 100_000


@dataclass(slots=True, eq=False)
class StrictGroup:
    """The lazy loads of one relationship for the parents of one query line.

    ``parents`` and ``first`` are those of the loads whose SELECT ran
    (``add_relationship_load``): a load that a ``do_orm_execute`` listener
    answers without one (a result cache), or that fails before it, is no
    lazy load for the report, so it does not count here either.
    """

    first: CallSite | None = None
    parents: set[object] = field(default_factory=set)
    suppressed: bool = False  # its finding is ignored or baselined
    # with units (QueryCollector.counts_units): the units whose finding is
    # ignored or baselined, as QueryCollector.unit_of names them
    suppressed_units: set[object] = field(default_factory=set)
    # with units: unit -> the parents counted in it, as ``parents`` (at most
    # the threshold each); a unit that turns out to share its lines joins
    # the unit None (QueryCollector._join_shared)
    units: dict[object, set[object]] = field(default_factory=dict)
    # (the report's location, parents from other lines), once at the threshold
    report: tuple[CallSite | None, bool] | None = None


@dataclass(slots=True, eq=False)
class QueryCollector:
    statements: list[StatementEvent] = field(default_factory=list)
    relationship_loads: list[RelationshipLoadEvent] = field(default_factory=list)
    column_loads: list[ColumnLoadEvent] = field(default_factory=list)
    # SELECTs that join collections side by side (cartesian.py); few per test
    cartesian_loads: list[CartesianLoadEvent] = field(default_factory=list)
    # Missing-index check (see indexes.py); only used when index_check is set.
    index_check: bool = False
    # Suggest an index for each finding; hypopg is "auto", "on" or "off".
    index_advisor: bool = False
    hypopg: str = "auto"
    # The ignore() blocks entered in the measured test's context, for the
    # stale-block report (see blocks.record_entered).
    blocks_entered: dict[tuple[str, int], IgnoreBlock] = field(default_factory=dict)
    # The blocks that left out a finding in a check run in that context, such
    # as QueryLog.assert_no_nplusone (an ordered set).
    blocks_used: dict[IgnoreBlock, None] | None = None
    explained: set[object] = field(default_factory=set)
    # A statement is explained at its first run only. For one first explained
    # inside an ignore() block: explain key -> the blocks of every run of it
    # (blocks.current() of each), so a run outside the block is not missed.
    index_runs: dict[object, dict[tuple[IgnoreBlock, ...], None]] = field(
        default_factory=dict
    )
    # The runs of the scans recorded before a catalog change, which makes the
    # statements be explained again (see freeze_index_runs): id(scan) -> its
    # runs, None for a statement not followed (its own run is all). None until
    # the first change: most tests run no DDL.
    frozen_runs: dict[int, dict[tuple[IgnoreBlock, ...], None] | None] | None = None
    frozen_scans: int = 0  # how many of scans have their runs in frozen_runs
    scans: list[ScanEvent] = field(default_factory=list)
    index_notices: dict[str, None] = field(default_factory=dict)  # ordered set
    explain_errors: list[tuple[str, str]] = field(default_factory=list)
    # One entry per statement left out because a partial index may serve it:
    # the tables of that statement's skipped scans.
    partial_skipped: list[tuple[str, ...]] = field(default_factory=list)
    # Most statements (and, separately, relationship loads) whose details are
    # stored; None for no limit. Past it the collector only counts.
    max_events: int | None = None
    # Counts statements only (the queryguard fixture's): it gets no relationship,
    # column or cartesian loads, and while only such collectors are active the
    # listeners skip the work those need.
    statements_only: bool = False
    # Set when a context-local collector is taken off: copies of its context
    # (tasks, threads) that outlive the block send it nothing more.
    closed: bool = False
    statement_count: int = 0
    relationship_load_count: int = 0
    column_load_count: int = 0
    cartesian_load_count: int = 0
    # Seconds the statements took, all of them, stored or only counted.
    db_time: float = 0.0
    # Strict mode (queryguard_strict): called with a lazy load, the call site
    # of the first lazy load of its group and the number of parents, once the
    # relationship has been lazy-loaded for ``strict_threshold`` parents that
    # one query line loaded; returns the exception to raise, or None.
    strict: (
        Callable[
            [RelationshipLoadEvent, CallSite | None, int, bool], BaseException | None
        ]
        | None
    ) = None
    strict_threshold: int = 2
    # count each Session on its own, as queryguard_scope = session does
    strict_by_scope: bool = False
    # count the lazy loads of test code too (RelationshipLoadEvent.test_code),
    # as queryguard_test_code = fail does
    strict_test_code: bool = True
    # The application lines a scope began from (callsite.find_entry), see
    # unit_of: lines -> the one scope begun from them, None once several
    # were (at most MAX_ENTRIES lines), and scope -> its lines for the
    # scopes whose lines no other scope began from. Made at the first entry,
    # not with the collector: most collectors never get one, and a dict made
    # and dropped per test changes what tracemalloc attributes on Python
    # before 3.14 (the memory stress test).
    entry_scope: dict[Entry, int | None] | None = None
    entries: dict[int, Entry] | None = None
    # (relationship, query site of the parents, Session or None) -> group
    strict_groups: dict[tuple[object, ...], StrictGroup] = field(default_factory=dict)
    # Set by the strict listener when it raises this collector's error: the
    # test may then fail with another exception (a library that wrapped the
    # strict one, or a failure after code that swallowed it).
    strict_raised: bool = False
    # The generation push() gave it: the origins of instances (where their
    # query ran, see listeners._ORIGIN_ATTR) noted from then on are its own.
    since: int = 0
    # Guards the counters and the length checks on a free-threaded build.
    _lock: threading.Lock = field(
        default_factory=threading.Lock, init=False, repr=False, compare=False
    )

    @property
    def truncated(self) -> bool:
        """True when some statements or loads were counted but not stored."""
        return (
            self.statement_count > len(self.statements)
            or self.relationship_load_count > len(self.relationship_loads)
            or self.column_load_count > len(self.column_loads)
            or self.cartesian_load_count > len(self.cartesian_loads)
        )

    def add_statement(self, event: StatementEvent) -> None:
        # The body is written twice, not shared, so the GIL build pays no
        # extra call for the free-threaded one.
        if _FREE_THREADED:
            with self._lock:
                self.statement_count += 1
                if self.max_events is None or len(self.statements) < self.max_events:
                    self.statements.append(event)
            return
        self.statement_count += 1
        if self.max_events is None or len(self.statements) < self.max_events:
            self.statements.append(event)

    def add_relationship_load(self, event: RelationshipLoadEvent) -> None:
        if _FREE_THREADED:
            with self._lock:
                if self.strict is not None:
                    self._strict_ran(event)
                self.relationship_load_count += 1
                if (
                    self.max_events is None
                    or len(self.relationship_loads) < self.max_events
                ):
                    self.relationship_loads.append(event)
            return
        if self.strict is not None:
            self._strict_ran(event)
        self.relationship_load_count += 1
        if self.max_events is None or len(self.relationship_loads) < self.max_events:
            self.relationship_loads.append(event)

    def add_column_load(self, event: ColumnLoadEvent) -> None:
        if _FREE_THREADED:
            with self._lock:
                self.column_load_count += 1
                if self.max_events is None or len(self.column_loads) < self.max_events:
                    self.column_loads.append(event)
            return
        self.column_load_count += 1
        if self.max_events is None or len(self.column_loads) < self.max_events:
            self.column_loads.append(event)

    def add_cartesian_load(self, event: CartesianLoadEvent) -> None:
        if _FREE_THREADED:
            with self._lock:
                self.cartesian_load_count += 1
                if (
                    self.max_events is None
                    or len(self.cartesian_loads) < self.max_events
                ):
                    self.cartesian_loads.append(event)
            return
        self.cartesian_load_count += 1
        if self.max_events is None or len(self.cartesian_loads) < self.max_events:
            self.cartesian_loads.append(event)

    def note_entry(self, scope: int, lines: Entry) -> None:
        """Scope ``scope`` began from these application lines (find_entry)."""
        if _FREE_THREADED:
            with self._lock:
                self._note_entry(scope, lines)
        else:
            self._note_entry(scope, lines)

    def _note_entry(self, scope: int, lines: Entry) -> None:
        entry_scope, entries = self.entry_scope, self.entries
        if entry_scope is None or entries is None:
            entry_scope = self.entry_scope = {}
            entries = self.entries = {}
        if lines in entry_scope:
            first = entry_scope[lines]
            if first is not None and first != scope:
                # its lines repeat: no longer a unit of its own
                entry_scope[lines] = None
                del entries[first]
                self._join_shared(first)
            return
        if len(entry_scope) < MAX_ENTRIES:
            entry_scope[lines] = scope
            entries[scope] = lines

    def _join_shared(self, scope: int) -> None:
        """Strict mode: the parents counted in unit ``scope`` join unit None."""
        for group in self.strict_groups.values():
            moved = group.units.pop(scope, None)
            if moved:
                group.units.setdefault(None, set()).update(moved)

    def counts_units(self) -> bool:
        """Whether the scope "test" counts by unit (``unit_of``).

        Only when some scope's lines are known, and every event was stored:
        past ``max_events`` the stored events are not all there is, and the
        whole test is counted together, as before.
        """
        return bool(self.entry_scope) and not self.truncated

    def unit_of(self, scope: int | None) -> int | None:
        """What the count rules count ``scope`` with, by default (scope "test").

        A Session (or connection checkout) begun from application lines that
        no other scope of the measurement began from is a unit of work of its
        own: a call on a line of its own, such as a store method that opens a
        Session per call. Its number is returned, and it is counted alone.
        The scopes begun from shared lines (the passes of a loop, the tasks of
        a fan-out) and those whose lines are unknown return None and are
        counted together, whatever lines each began from, so that a loop
        whose passes take two paths is not split in two.

        A request of Django's test client is always a unit of its own
        (``boundary``).
        """
        if isinstance(scope, RequestScope):
            return scope
        entries = self.entries
        if scope is None or entries is None or scope not in entries:
            return None
        return scope

    def strict_check(self, load: RelationshipLoadEvent) -> BaseException | None:
        """The strict-mode exception for this lazy load, or None.

        Only lazy loads of parents whose query line is known count, so an
        object read on its own, or objects the test made itself, never raise
        here. A group whose finding is ignored or baselined is decided once.
        A load inside an ``ignore("relationship-load")`` block never raises.
        """
        strict = self.strict
        key = self._strict_key(load)
        if strict is None or key is None:
            return None
        if load.test_code and not self.strict_test_code:
            return None
        scope = key[2]
        if _FREE_THREADED:
            with self._lock:
                decided = self._strict_decide(key, load, scope)
        else:
            decided = self._strict_decide(key, load, scope)
        if decided is None:
            return None
        group, unit, (first, other_lines), parents = decided
        error = strict(load, first, parents, other_lines)
        if error is None:
            if unit is _ALL:
                group.suppressed = True
            else:
                group.suppressed_units.add(unit)
        return error

    def _strict_decide(
        self, key: tuple[object, ...], load: RelationshipLoadEvent, scope: object
    ) -> tuple[StrictGroup, object, tuple[CallSite | None, bool], int] | None:
        """(group, unit, (site, other lines), parents) once the load raises.

        With scope "test" and units (``counts_units``), the parents are
        counted in the load's unit only (``unit_of``), as the report counts
        them: a Session begun from lines of its own is no pass of a loop. The
        unit is ``_ALL`` without units. A load inside an
        ``ignore("relationship-load")`` block counts for the group (a later
        load outside the block raises) but never raises itself.
        """
        group = self._strict_group(key, load)
        if group is None:
            return None
        if self.strict_by_scope or not self.counts_units():
            if group.report is None:
                group.report = self._report_site(load, scope)
            if load.ignores and covers(load.ignores, KIND_RELATIONSHIP):
                return None
            first, other_lines = group.report
            site = first or group.first or load.callsite
            return group, _ALL, (site, other_lines), self._strict_count(group, load)
        if load.ignores and covers(load.ignores, KIND_RELATIONSHIP):
            return None
        unit = self.unit_of(load.scope)
        if unit in group.suppressed_units:
            return None
        # the parents of this unit whose lazy load ran (_strict_ran), with
        # this load's
        parents = group.units.get(unit, set())
        count = len(parents) + (load.parent_key not in parents)
        if count < self.strict_threshold:
            return None
        first, other_lines = self._report_site(load, scope, unit)
        # the fallback is this unit's load: group.first may be another unit's
        site = first or load.callsite
        return group, unit, (site, other_lines), min(count, self.strict_threshold)

    def _report_site(
        self, load: RelationshipLoadEvent, scope: object | None, unit: object = _ALL
    ) -> tuple[CallSite | None, bool]:
        """(where the report puts this N+1, whether other lines loaded parents).

        The report makes one finding per relationship (per scope with
        ``queryguard_repeat_scope = session``) from the query lines whose
        parents make an N+1, located at its first lazy load; ignore patterns
        and the baseline must match that line, not the first load of this
        group's line. Loads of parents whose query is unknown join it when
        read where its parents were read (or where no line is known), or when
        those read at their line are an N+1 of their own, as in the report.
        When parents of other lines are in it, the
        report's finding has no patch, so neither has the strict error.
        Computed once per group, when it reaches the threshold, or, with
        ``unit``, from the loads of that unit only (see ``_strict_decide``).
        """
        here = query_line(load)
        first: CallSite | None = None
        other_lines = False
        loads = [
            earlier
            for earlier in self.relationship_loads
            if earlier.relationship == load.relationship
            and earlier.parent_key is not None
            and (
                (scope is None or earlier.scope == scope)
                if self.strict_by_scope
                else boundary(earlier.scope) == scope
            )
            and (unit is _ALL or self.unit_of(earlier.scope) == unit)
        ]
        # with a unit, its parents per query line, as the report counts them
        per_line: dict[object, set[object]] = {}
        if unit is not _ALL:
            for earlier in loads:
                line = query_line(earlier)
                if line is not None:
                    per_line.setdefault(line, set()).add(earlier.parent_key)
        # the lines that read this group's relationship: a parent of unknown
        # origin joins the group when read at one of them (or at no known line)
        reads = {
            earlier.callsite
            for earlier in loads
            if earlier.parent is not None and query_line(earlier) == here
        }
        reads.add(load.callsite)
        # the parents of unknown origin per reading line, as the report groups
        # them; one read at no known line counts for every line
        unknown: dict[object, set[object]] = {}
        for earlier in loads:
            if earlier.parent is None or earlier.parent.callsite is None:
                unknown.setdefault(read_key(earlier), set()).add(earlier.parent_key)
        anywhere = unknown.get(None, set())
        for earlier in loads:
            line = query_line(earlier)
            if line is None and earlier.callsite is not None:
                if earlier.callsite not in reads and (
                    len(unknown[read_key(earlier)] | anywhere) < self.strict_threshold
                ):
                    continue  # read elsewhere, too few to be an N+1 of its own
            elif line is not None and line != here:
                if unit is _ALL:
                    group = self.strict_groups.get((load.relationship, line, scope))
                    count = 0 if group is None else len(group.parents)
                else:
                    count = len(per_line.get(line, ()))
                if count < self.strict_threshold:
                    continue  # a line with too few parents is no N+1
            if first is None and earlier.callsite is not None:
                first = earlier.callsite
            if _site_of(line) != _site_of(here):
                other_lines = True  # as the report: query lines, not call paths
        return first, other_lines

    def _strict_key(self, load: RelationshipLoadEvent) -> tuple[object, ...] | None:
        """(relationship, query line of the parents (``query_line``), scope),
        or None when it is unknown (such loads never count here)."""
        line = query_line(load)
        if line is None:
            return None
        scope = load.scope if self.strict_by_scope else boundary(load.scope)
        return (load.relationship, line, scope)

    def _strict_group(
        self, key: tuple[object, ...], load: RelationshipLoadEvent
    ) -> StrictGroup | None:
        """The group of this load once it, with the parents whose lazy load
        ran before it, reaches the threshold; else None. The load itself
        counts once its SELECT runs (``_strict_ran``)."""
        group = self.strict_groups.get(key)
        if group is None:
            group = self.strict_groups[key] = StrictGroup()
        if group.suppressed:
            return None
        return (
            group if self._strict_count(group, load) >= self.strict_threshold else None
        )

    def _strict_count(self, group: StrictGroup, load: RelationshipLoadEvent) -> int:
        """The parents of the group with this load's, at most the threshold."""
        parents = group.parents
        count = len(parents) + (load.parent_key not in parents)
        return min(count, self.strict_threshold)

    def _strict_ran(self, load: RelationshipLoadEvent) -> None:
        """A lazy load ran its SELECT (or raised in strict mode): its parent
        now counts for the group ``strict_check`` made for it."""
        key = self._strict_key(load)
        group = None if key is None else self.strict_groups.get(key)
        if group is None or (load.test_code and not self.strict_test_code):
            return
        if len(group.parents) < self.strict_threshold:
            group.parents.add(load.parent_key)  # no more is needed
            if group.first is None:
                group.first = load.callsite
        # per unit too, for when the test counts by unit (_strict_decide)
        unit = group.units.setdefault(self.unit_of(load.scope), set())
        if len(unit) < self.strict_threshold:
            unit.add(load.parent_key)

    def freeze_index_runs(self) -> None:
        """Keep the runs of the scans so far; the statements start afresh.

        After a catalog change a statement is explained again: its later runs
        belong to that explain, and do not count for the scans before it.
        """
        scans = self.scans[self.frozen_scans :]
        if scans:
            if self.frozen_runs is None:
                self.frozen_runs = {}
            for scan in scans:
                self.frozen_runs[id(scan)] = self.index_runs.get(scan.key)
            self.frozen_scans += len(scans)
        if self.index_runs:
            self.index_runs = {}

    def runs_of(self, scan: ScanEvent) -> dict[tuple[IgnoreBlock, ...], None] | None:
        """The blocks of every run of ``scan``'s statement, or None if not followed."""
        frozen = self.frozen_runs
        if frozen is not None and id(scan) in frozen:
            return frozen[id(scan)]
        return self.index_runs.get(scan.key)

    def note_index_run(self, key: object, tags: tuple[IgnoreBlock, ...]) -> None:
        """Another run of an explained statement (see ``index_runs``)."""
        runs = self.index_runs.get(key)
        if runs is not None and tags not in runs:
            runs[tags] = None

    def add_db_time(self, seconds: float) -> None:
        if _FREE_THREADED:
            with self._lock:
                self.db_time += seconds
        else:
            self.db_time += seconds


def note_index_reruns(
    targets: Sequence[QueryCollector], fresh: Sequence[QueryCollector], key: object
) -> None:
    """The statement under ``key`` ran again for the targets not in ``fresh``.

    Only a statement first explained inside an ignore() block is followed, so
    the usual cost is a dict lookup per collector.
    """
    if len(fresh) == len(targets):
        return
    tags: tuple[IgnoreBlock, ...] | None = None
    for target in targets:
        if key not in target.index_runs or any(t is target for t in fresh):
            continue
        if tags is None:
            tags = current_blocks()
        target.note_index_run(key, tags)


def note_index_first_run(
    fresh: Sequence[QueryCollector], key: object, tags: tuple[IgnoreBlock, ...]
) -> None:
    """The statement under ``key`` was explained, with scans, inside ``tags``."""
    if tags:
        for target in fresh:
            target.index_runs[key] = {tags: None}


# Process-wide on purpose: the code under test may run in another thread.
_stack: list[QueryCollector] = []
# The tuples active() and full_active() return, rebuilt on push and pop only:
# the listeners call them for every statement.
_active: tuple[QueryCollector, ...] = ()
_active_full: tuple[QueryCollector, ...] = ()
# The same as _active_full, as a list that is never rebound: the per-row
# listeners read it without a call (listeners._collectors).
_full_stack: list[QueryCollector] = []
_generation = 0


class RequestScope(int):
    """The scope number of a request of Django's test client, or of the
    connection of a thread that test code started (django_backend._scope_of).

    Always counted on its own, whatever queryguard_scope says: a loop of the
    test over requests is not a loop of the application. With
    queryguard_scope = test everything else still counts together.
    """

    __slots__ = ()


def _site_of(line: object) -> object:
    """The query's call site of a ``query_line()`` key, without its path."""
    return line[0] if isinstance(line, tuple) else line


def boundary(scope: object) -> object:
    """The scope ``scope`` always counts in with ``queryguard_scope = test``:
    itself for a request, else None (the whole test)."""
    return scope if isinstance(scope, RequestScope) else None


def for_target(
    load: RelationshipLoadEvent, target: QueryCollector
) -> RelationshipLoadEvent:
    """``load`` as ``target`` records it: without the parent's origin when that
    was noted before ``target`` started (an object loaded before a
    ``record_queries()`` block has none there)."""
    parent = load.parent
    if parent is None or parent.noted >= target.since:
        return load
    return replace(load, parent=None)


def generation() -> int:
    """Changes on every push/pop; lets per-measurement state detect staleness."""
    return _generation


def _rebuild() -> None:
    global _active, _active_full
    _active = tuple(_stack)
    _active_full = tuple(c for c in _active if not c.statements_only)
    _full_stack[:] = _active_full


# Called with no arguments at the start of each process-wide measurement
# (push): an ORM integration that can only hook in once its ORM is configured
# (Django, see backends.py) does it here. A hook must never raise.
_push_hooks: list[Callable[[], None]] = []


def on_push(hook: Callable[[], None]) -> None:
    """Call ``hook`` at the start of every measurement from now on (once per hook)."""
    if hook not in _push_hooks:
        _push_hooks.append(hook)


# Called with no arguments when a context-local collector opens (push_local),
# and when the last collector of any kind closes (idle): an integration that
# hooks into each statement (Django's execute wrapper) only while something
# measures. A hook must never raise.
_local_push_hooks: list[Callable[[], None]] = []
_idle_hooks: list[Callable[[], None]] = []


def on_push_local(hook: Callable[[], None]) -> None:
    if hook not in _local_push_hooks:
        _local_push_hooks.append(hook)


def on_idle(hook: Callable[[], None]) -> None:
    if hook not in _idle_hooks:
        _idle_hooks.append(hook)


def _maybe_idle() -> None:
    if not _stack and not _live_local:
        for hook in _idle_hooks:
            hook()


def push(collector: QueryCollector) -> None:
    global _generation
    for hook in _push_hooks:
        hook()
    _generation += 1
    collector.since = _generation
    callsite.new_measurement()
    _stack.append(collector)
    _rebuild()


def pop(collector: QueryCollector) -> None:
    global _generation
    _generation += 1
    for i in range(len(_stack) - 1, -1, -1):
        if _stack[i] is collector:
            del _stack[i]
            break
    _rebuild()
    callsite.end_measurement()
    _maybe_idle()


def active() -> tuple[QueryCollector, ...]:
    return _active


def full_active() -> tuple[QueryCollector, ...]:
    """The active collectors that want loads too, not only statements."""
    return _active_full


# Statements-only collectors that count only the statements run in the
# context that pushed them (the queryguard fixture's blocks): the test's
# thread or asyncio task, and the tasks and threads that run in a copy of its
# context (a task created inside the block, asyncio.to_thread, any new thread
# on a free-threaded build). They do not change the generation: the
# attributions of other tasks and of the process-wide collectors stay valid.
_local: ContextVar[tuple[QueryCollector, ...]] = ContextVar(
    "queryguard_local", default=()
)
_local_lock = threading.Lock()
# Open context-local collectors in the process; while 0, targets() is active().
_live_local = 0
# Bumped when one closes, so the cached combination below is rebuilt.
_local_version = 0
# (active, local tuple, version, combined): the last combination built.
_combined: tuple[object, object, int, tuple[QueryCollector, ...]] | None = None


def push_local(collector: QueryCollector) -> None:
    global _live_local
    for hook in _local_push_hooks:
        hook()
    with _local_lock:
        _live_local += 1
    _local.set((*_local.get(), collector))


def pop_local(collector: QueryCollector) -> None:
    """Close ``collector`` and take it off this context's stack.

    Other contexts that still hold it (copies made inside the block) skip it
    from now on.
    """
    global _live_local, _local_version, _combined
    with _local_lock:
        if not collector.closed:
            collector.closed = True
            _live_local -= 1
            _local_version += 1
            _combined = None
    stack = _local.get()
    for i in range(len(stack) - 1, -1, -1):
        if stack[i] is collector:
            _local.set(stack[:i] + stack[i + 1 :])
            break
    _maybe_idle()


def open_local(collector: QueryCollector) -> None:
    """Open a context-local collector that no context holds yet.

    ``enter_local`` adds it to a context, ``exit_local`` takes it out again,
    and ``pop_local`` closes it: for a unit that its own code leaves and
    re-enters, such as an HTTP request whose body is read after the call.
    """
    global _live_local
    for hook in _local_push_hooks:
        hook()
    with _local_lock:
        _live_local += 1


def enter_local(collector: QueryCollector) -> Token[tuple[QueryCollector, ...]]:
    """Add an open context-local collector to this context; see ``open_local``."""
    return _local.set((*_local.get(), collector))


def exit_local(
    collector: QueryCollector, token: Token[tuple[QueryCollector, ...]]
) -> None:
    """Undo ``enter_local``; from another context, only take ``collector`` off."""
    try:
        _local.reset(token)
    except ValueError:
        stack = _local.get()
        if collector in stack:
            _local.set(tuple(c for c in stack if c is not collector))


def targets() -> tuple[QueryCollector, ...]:
    """The collectors a statement of this thread or task goes to."""
    global _combined
    if not _live_local:
        return _active
    local = _local.get()
    if not local:
        return _active
    active, version, cached = _active, _local_version, _combined
    if (
        cached is not None
        and cached[0] is active
        and cached[1] is local
        and cached[2] == version
    ):
        return cached[3]
    live = tuple(c for c in local if not c.closed)
    combined = (*active, *live) if live else active
    _combined = (active, local, version, combined)
    return combined


def _reset_for_tests() -> None:
    global _generation, _live_local, _local_version, _combined
    _generation += 1
    _stack.clear()
    _rebuild()
    _local.set(())
    with _local_lock:
        _live_local = 0
        _local_version += 1
        _combined = None
