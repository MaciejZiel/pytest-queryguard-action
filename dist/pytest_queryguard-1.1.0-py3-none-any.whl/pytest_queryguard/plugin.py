from __future__ import annotations

import contextlib
import glob
import importlib
import importlib.metadata
import os
import shlex
import sys
import time
import warnings as std_warnings
from collections.abc import Callable, Generator, Sequence
from dataclasses import dataclass, replace
from fnmatch import fnmatchcase
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

import pytest

if TYPE_CHECKING:
    from . import eager, unused_columns

from . import baseline as baselines
from . import (
    blocks,
    catalog,
    fixpatch,
    hypopg,
    indexes,
    routes,
    sarif,
    testjson,
)
from . import budgets as budget_files
from . import groups as finding_groups
from .api import NPlusOneDetected, QueryGuardFixture, add_to_strict_error
from .backends import (
    disable_cartesian,
    disable_strict,
    enable_cartesian,
    enable_strict,
    install,
    install_index_check,
)
from .backends import ready as backends_ready
from .baseline import BaselineError, Identity, sorted_identities
from .callsite import (
    DEFAULT_STACK_DEPTH,
    TestCode,
    set_track_calls,
    swap_stack_depth,
    swap_test_code,
    trim_to_user_code,
)
from .collector import QueryCollector, pop, push
from .detectors import (
    DEFAULT_COLUMN_LOAD_THRESHOLD,
    SCOPE_SESSION,
    SCOPE_TEST,
    SCOPES,
    Detection,
    RelationshipFinding,
    detect,
)
from .errors import (
    internal_error,
    internal_failure,
    record_error,
    swap_error,
)
from .events import CallSite, RelationshipLoadEvent, ScanEvent
from .fileio import atomic_write_text
from .findings import (
    KIND_CARTESIAN_LOAD,
    KIND_COLUMN_LOAD,
    KIND_MISSING_INDEX,
    KIND_RELATIONSHIP,
    KIND_REPEAT,
    KIND_UNUSED_COLUMNS,
    KIND_UNUSED_EAGER_LOAD,
    KIND_WRITE_LOOP,
    Finding,
    SourceFix,
)
from .ignores import IgnoreRule, apply_rules, check_kind, parse_rules
from .indexes import scan_key, select_findings
from .messages import (
    _display_path,
    format_budget,
    format_failure,
    format_findings,
    format_index_findings,
    format_index_notes,
    format_stale_baseline,
    format_stale_ignores,
    format_strict,
    format_test_code_summary,
    format_time_budget,
    format_truncation,
    make_finding,
    make_findings,
    make_index_finding,
    swap_root,
)
from .warnings import (
    REMOVED_IN,
    QueryGuardDeprecationWarning,
    QueryGuardInternalWarning,
    QueryGuardWarning,
    warn_internal,
)


def _sqlalchemy_check(name: str) -> Any:
    """The module of an opt-in SQLAlchemy check, imported when first used.

    They import SQLAlchemy; a project that does not switch them on (or uses
    only Django) never imports it through them.
    """
    return importlib.import_module(f"pytest_queryguard.{name}")


_MODES = ("fail", "warn", "off")
_EAGER_MODES = ("off", "warn", "fail")
_eager_enabled = pytest.StashKey[bool]()
_columns_enabled = pytest.StashKey[bool]()
_cartesian_enabled = pytest.StashKey[bool]()
_strict_enabled = pytest.StashKey[bool]()
_internal_reported = pytest.StashKey[bool]()
# Set on a test item once its function starts: a queryguard fixture requested
# later (request.getfixturevalue in the test) starts counting at once.
_call_started = pytest.StashKey[bool]()
# The queryguard fixtures of a test item, however they were requested.
_guards = pytest.StashKey[list[QueryGuardFixture]]()
_failure_summarised = pytest.StashKey[bool]()
_outer_error = pytest.StashKey[BaseException | None]()
_outer_stopped = pytest.StashKey[str | None]()
_outer_catalog_error = pytest.StashKey[str | None]()
_outer_no_plpgsql = pytest.StashKey[indexes.EngineSet]()
_outer_root = pytest.StashKey[Path | None]()
_outer_stack_depth = pytest.StashKey[int]()
_outer_test_code = pytest.StashKey[TestCode]()
_outer_track_calls = pytest.StashKey[bool]()
_test_code = pytest.StashKey[TestCode]()
_settings = pytest.StashKey["_Settings"]()
_report = pytest.StashKey[list[tuple[str, int]]]()
_index_notes = pytest.StashKey["_IndexNotes"]()
_REPORT_SIZE = 10
# Statements and relationship loads stored per test; generous, a test that
# needs more is far past any N+1 threshold already.
DEFAULT_MAX_EVENTS = 10_000


class _Settings:
    def __init__(
        self,
        mode: str,
        relationship: int,
        repeat: int,
        index_check: bool = False,
        ignore_tables: tuple[str, ...] = (),
        max_events: int | None = DEFAULT_MAX_EVENTS,
        ignore: tuple[IgnoreRule, ...] = (),
        column_load: int = DEFAULT_COLUMN_LOAD_THRESHOLD,
        small_repeat: int | None = None,
        fail_on: tuple[str, ...] = (),
        write_loop: int | None = None,
        unused_eager: str = "off",
        baseline_path: Path | None = None,
        update_baseline: bool = False,
        baseline: frozenset[Identity] | None = None,
        sarif_path: Path | None = None,
        index_advisor: bool = True,
        hypopg: str = "auto",
        repeat_scope: str = SCOPE_TEST,
    ) -> None:
        self.mode = mode
        self.repeat_scope = repeat_scope
        self.relationship = relationship
        self.repeat = repeat
        self.index_check = index_check
        self.ignore_tables = ignore_tables
        self.max_events = max_events
        self.ignore = ignore
        self.column_load = column_load
        self.small_repeat = small_repeat
        self.fail_on = fail_on
        self.write_loop = write_loop
        self.unused_eager = unused_eager
        self.index_advisor = index_advisor
        self.hypopg = hypopg
        self.baseline_path = baseline_path
        self.sarif_path = sarif_path
        self.rootpath: Path | None = None  # for the SARIF location prefix
        # findings that count (not ignored, not baselined), for the SARIF file
        self.reported: sarif.Collected = {}
        # the same counted finding in several tests, for the terminal summary
        self.groups: finding_groups.Groups = {}
        self.cartesian = "warn"  # queryguard_cartesian_load
        # queryguard_test_code: what findings of the test code do (off: they
        # are only counted for the summary section)
        self.test_code = "off"
        # with off: node id -> findings left out, for the summary section (by
        # node id: with --dist each every worker runs every test)
        self.test_code_left_out: dict[str, int] = {}
        self.unused_columns = "off"  # queryguard_unused_columns
        self.strict = False  # queryguard_strict
        # budgets: queryguard_max_queries, the budget file and its update
        self.default_budget: int | None = None
        # queryguard_route_budgets and queryguard_route_default_budget
        self.route_budgets: dict[str, int] = {}
        self.route_default: int | None = None
        self.budgets_path: Path | None = None
        self.budgets: dict[str, int] = {}
        self.update_budgets = False
        self.budgets_written: str | None = None
        self.budgets_failed: str | None = None
        self.budgets_previous_error: str | None = None
        # for the update: the node ids collected and those that failed
        self.collected: set[str] = set()
        self.failed: set[str] = set()
        # per-test counts and findings for --queryguard-json
        self.json_path: Path | None = None
        self.tests: testjson.Tests = {}
        self.json_incomplete = False
        self.json_result: str | None = None
        self.json_failed: str | None = None
        self.sarif_result: str | None = None
        self.sarif_failed: str | None = None
        self.update_baseline = update_baseline
        # None: no baseline in use (or one that is about to be rewritten, which
        # then starts empty and is compared with what the run finds)
        self.baseline = baseline
        # identities of the findings the run made (after ignores), baselined or not
        self.seen: set[Identity] = set()
        # (rootdir-relative file, function) of every test that ran its call
        # phase, and whether this session deselected any test (-k, -m, --lf,
        # --deselect); both feed a partial baseline update and the stale lists
        self.executed: set[tuple[str | None, str]] = set()
        self.deselected = False
        # set at the end of the session: the run stopped before every selected
        # test ran (-x, Ctrl-C, a collection error), and it did not run the
        # whole suite (stopped, narrowed or --collect-only); a pattern or an
        # entry that matched nothing may then be for a test that did not run
        self.run_stopped = False
        self.run_partial = False
        # the run is incomplete: a worker crashed or stopped measuring
        self.baseline_incomplete = False
        # a collection error was reported (by this process or an xdist worker)
        self.collection_failed = False
        self.baseline_previous_error: str | None = None
        self.baseline_written: str | None = None
        self.baseline_failed: str | None = None
        # what the ignores did, for the stale-ignore warning in the summary
        self.ignore_used: set[IgnoreRule] = set()
        # (test, rule, name of the marker it comes from)
        self.stale_markers: list[tuple[str, IgnoreRule, str]] = []
        # ignore() blocks entered in a test that was analysed, as
        # "file:line" -> "ignore('kind')", and those that left out a finding;
        # incomplete when a pytest-xdist worker did not send them
        self.blocks_entered: dict[str, str] = {}
        self.blocks_used: set[str] = set()
        self.blocks_incomplete = False
        # a pytest-xdist worker did not send the ignore patterns it used
        self.ignores_incomplete = False
        # a pytest-xdist worker did not send its counts for --queryguard-report
        self.report_incomplete = False
        # a pytest-xdist worker did not send its index-check notes
        self.index_notes_incomplete = False
        # patches that add the loader option (queryguard_show_patch,
        # --queryguard-write-patch); files modified after ``started`` get none
        self.show_patch = False
        self.patch_path: Path | None = None
        self.started = time.time()
        self.fixes: dict[SourceFix, None] = {}  # an ordered set
        self.fixes_incomplete = False
        self.patch_result: str | None = None
        self.patch_failed: str | None = None

    @property
    def baselining(self) -> bool:
        return self.baseline_path is not None

    @property
    def fixing(self) -> bool:
        """Whether findings get their source patch: shown, written or in SARIF."""
        return self.show_patch or self.patch_path is not None or bool(self.sarif_path)

    @property
    def counting(self) -> bool:
        """Whether each test's counts are kept: for the JSON or the budget update."""
        return self.json_path is not None or self.update_budgets

    def fails(self, kind: str) -> bool:
        """True when a finding of this kind fails the test; else it only warns."""
        if self.mode != "fail":
            return False
        return not self.fail_on or any(fnmatchcase(kind, p) for p in self.fail_on)


class _IndexNotes:
    """What the index check could not do, summed up over the session."""

    def __init__(self) -> None:
        self.notices: dict[str, None] = {}  # ordered set
        self.errors = 0
        self.partial_skipped: list[tuple[str, ...]] = []
        self.first_error: tuple[str, str] | None = None


# pytest 9 reads native [tool.pytest] TOML, where thresholds are real integers
# and a string-typed option would crash; older versions only know strings.
_NATIVE_INT = pytest.version_tuple >= (9,)
_INT_TYPE: dict[str, Any] = {"type": "int"} if _NATIVE_INT else {}
# What Config.getini() raises for a value that does not fit the option's type:
# TypeError or ValueError up to pytest 9.1, UsageError (with the bare
# conversion message) from 9.2. Every reader catches all three and raises its
# own UsageError that names the option and what it accepts.
_INI_ERRORS: tuple[type[Exception], ...] = (TypeError, ValueError, pytest.UsageError)


def pytest_addoption(parser: pytest.Parser) -> None:
    group = parser.getgroup("queryguard")
    group.addoption(
        "--queryguard-mode",
        dest="queryguard_mode",
        default=None,
        help="N+1 handling: fail, warn or off (overrides queryguard_mode).",
    )
    group.addoption(
        "--queryguard-strict",
        dest="queryguard_strict",
        action="store_const",
        const=True,
        default=None,
        help="Raise at the lazy load that makes an N+1 (by default the second "
        "parent from one query line), with the test's traceback (overrides "
        "queryguard_strict).",
    )
    group.addoption(
        "--no-queryguard-strict",
        dest="queryguard_strict",
        action="store_const",
        const=False,
        help="Turn strict mode off for this run.",
    )
    group.addoption(
        "--queryguard-report",
        dest="queryguard_report",
        action="store_true",
        default=False,
        help="Print the tests with the most queries at the end of the session.",
    )
    group.addoption(
        "--queryguard-index-check",
        dest="queryguard_index_check",
        action="store_const",
        const=True,
        default=None,
        help="Check statements for a missing index (PostgreSQL 16 or newer, SQLite, MySQL or MariaDB); "
        "overrides queryguard_index_check.",
    )
    group.addoption(
        "--no-queryguard-index-check",
        dest="queryguard_index_check",
        action="store_const",
        const=False,
        help="Turn the missing-index check off for this run.",
    )
    group.addoption(
        "--queryguard-baseline",
        dest="queryguard_baseline",
        default=None,
        metavar="PATH",
        help="Baseline file: findings listed in it do not fail or warn "
        "(overrides queryguard_baseline).",
    )
    group.addoption(
        "--queryguard-budgets",
        dest="queryguard_budgets",
        default=None,
        metavar="PATH",
        help="Budget file: each test listed in it fails above its number of "
        "queries (overrides queryguard_budgets).",
    )
    group.addoption(
        "--queryguard-update-budgets",
        dest="queryguard_update_budgets",
        action="store_true",
        default=False,
        help="Write each test's query count of this run to the budget file. "
        "On a partial run the entries of tests that did not run are kept.",
    )
    group.addoption(
        "--queryguard-update-baseline",
        dest="queryguard_update_baseline",
        action="store_true",
        default=False,
        help="Write the findings of this run to the baseline file instead of "
        "reporting them. On a partial run (-k, -m, --lf, a path) only the "
        "entries of tests that ran are replaced.",
    )
    group.addoption(
        "--queryguard-sarif",
        dest="queryguard_sarif",
        default=None,
        metavar="PATH",
        help="Write the findings of this run to PATH as SARIF 2.1.0 (GitHub "
        "code scanning). Findings in the baseline are left out.",
    )
    group.addoption(
        "--queryguard-show-patch",
        dest="queryguard_show_patch",
        action="store_const",
        const=True,
        default=None,
        help="EXPERIMENTAL: print a patch under each relationship-load finding "
        "whose parent query line is certain (overrides queryguard_show_patch).",
    )
    group.addoption(
        "--no-queryguard-show-patch",
        dest="queryguard_show_patch",
        action="store_const",
        const=False,
        help="Do not print the patches for this run.",
    )
    group.addoption(
        "--queryguard-write-patch",
        dest="queryguard_write_patch",
        default=None,
        metavar="PATH",
        help="EXPERIMENTAL: write the patches of this run's relationship-load "
        "findings to PATH as one file for git apply (from the rootdir).",
    )
    group.addoption(
        "--queryguard-json",
        dest="queryguard_json",
        default=None,
        metavar="PATH",
        help="Write each test's statement counts and findings to PATH as JSON, "
        "to compare runs (a pull request against its base branch).",
    )
    parser.addini("queryguard_mode", "fail, warn or off", default="fail")
    parser.addini(
        "queryguard_relationship_threshold",
        "Parents of one query line whose lazy loads of one relationship are an N+1 (integer >= 2)",
        default=2 if _NATIVE_INT else "2",
        **_INT_TYPE,
    )
    parser.addini(
        "queryguard_repeat_threshold",
        "Executions of one statement treated as N+1 (integer >= 2)",
        default=5 if _NATIVE_INT else "5",
        **_INT_TYPE,
    )
    parser.addini(
        "queryguard_small_repeat_threshold",
        "Executions (below queryguard_repeat_threshold) of one statement from one "
        "source line, each with different parameters, treated as N+1; 0 turns "
        "this off (integer >= 2, or 0)",
        default=0 if _NATIVE_INT else "0",
        **_INT_TYPE,
    )
    parser.addini(
        "queryguard_write_loop_threshold",
        "Row-by-row INSERT, UPDATE or DELETE statements of one shape from one "
        "source line treated as a write loop; 0 turns the check off (integer "
        ">= 2, or 0)",
        default=0 if _NATIVE_INT else "0",
        **_INT_TYPE,
    )
    parser.addini(
        "queryguard_scope",
        "What the repeat, relationship, column-load and write-loop rules count "
        "together: test (everything one test runs; the default) or session (each "
        "database session on its own, for tests that make several requests; with "
        "SQLAlchemy, a session is a Session or a connection checkout)",
        default=None,
    )
    parser.addini(
        "queryguard_repeat_scope",
        "Deprecated name of queryguard_scope, removed in 2.0",
        default=None,
    )
    parser.addini(
        "queryguard_fail_on",
        "Finding kinds that fail a test in fail mode, one per line (fnmatch "
        "patterns); the other kinds only warn. Empty: every kind fails, except "
        "cartesian-load and the unused-* kinds unless their own option is fail",
        type="linelist",
        default=[],
    )
    parser.addini(
        "queryguard_column_load_threshold",
        "Instances of one class that must load deferred or expired columns on "
        "their own to count as N+1 (integer >= 2)",
        default=DEFAULT_COLUMN_LOAD_THRESHOLD
        if _NATIVE_INT
        else str(DEFAULT_COLUMN_LOAD_THRESHOLD),
        **_INT_TYPE,
    )
    parser.addini(
        "queryguard_max_events",
        "Statements stored per test for the report (integer >= 1, or 0 for no limit); "
        "beyond it they are only counted",
        default=DEFAULT_MAX_EVENTS if _NATIVE_INT else str(DEFAULT_MAX_EVENTS),
        **_INT_TYPE,
    )
    parser.addini(
        "queryguard_stack_depth",
        "Callers shown under the first location of a finding (integer >= 0, "
        "0 for none)",
        default=DEFAULT_STACK_DEPTH if _NATIVE_INT else str(DEFAULT_STACK_DEPTH),
        **_INT_TYPE,
    )
    parser.addini(
        "queryguard_ignore",
        "Findings to leave out of reports, one per line: "
        "KIND LABEL [file=GLOB] [function=GLOB] [stack=GLOB] (fnmatch patterns)",
        type="linelist",
        default=[],
    )
    parser.addini(
        "queryguard_strict",
        "Raise NPlusOneDetected at the lazy load that makes an N+1 (the parent "
        "that reaches queryguard_relationship_threshold among those loaded at one "
        "line), instead of reporting it when the test ends",
        type="bool",
        default=False,
    )
    parser.addini(
        "queryguard_show_patch",
        "EXPERIMENTAL: print a patch under each relationship-load finding whose "
        "parent query line is certain: the loader option added to its select() "
        "or query() call",
        type="bool",
        default=False,
    )
    parser.addini(
        "queryguard_test_code",
        "N+1 findings whose statements all ran in test code (test modules, "
        "conftest.py, factories, helpers under tests/): off (default, counted "
        "in a summary section), warn or fail",
        default="off",
    )
    parser.addini(
        "queryguard_cartesian_load",
        "One SELECT that joins two collections side by side (joinedload of both), "
        "whose rows grow as their product: warn (default), fail or off",
        default="warn",
    )
    parser.addini(
        "queryguard_unused_eager_load",
        "EXPERIMENTAL: report relationships a test loads with selectinload, "
        "joinedload, subqueryload or immediateload and never reads: off "
        "(default), warn or fail",
        default="off",
    )
    parser.addini(
        "queryguard_unused_columns",
        "EXPERIMENTAL: report wide rows (at least 8 columns) a test loads and "
        "reads at most half the columns of, suggesting load_only(): off "
        "(default), warn or fail",
        default="off",
    )
    parser.addini(
        "queryguard_budgets",
        "Budget file (relative to the rootdir): each test listed in it fails above "
        "its number of queries, unless it has a max_queries marker",
        default="",
    )
    parser.addini(
        "queryguard_max_queries",
        "Default query budget of every test that has no max_queries marker and no "
        "entry in the budget file (integer >= 0; empty: none)",
        default="",
    )
    parser.addini(
        routes.INI_BUDGETS,
        "EXPERIMENTAL: the most SQL statements one request of a route may run, "
        'one "PATTERN=LIMIT" per line ("GET /books/{id}=5"); for requests a test '
        "sends to a Starlette, FastAPI, Litestar, Flask or Django application",
        type="linelist",
        default=[],
    )
    parser.addini(
        routes.INI_DEFAULT,
        "EXPERIMENTAL: the statement budget of every request no "
        "queryguard_route_budgets pattern matches (integer >= 0; empty: none)",
        default="",
    )
    parser.addini(
        "queryguard_baseline",
        "Baseline file (relative to the rootdir): findings listed in it do not "
        "fail or warn",
        default="",
    )
    parser.addini(
        "queryguard_index_check",
        "Check statements for a missing index (PostgreSQL 16 or newer, SQLite, MySQL or MariaDB)",
        type="bool",
        default=False,
    )
    parser.addini(
        "queryguard_index_advisor",
        "Suggest a CREATE INDEX for each missing-index finding (used with the "
        "index check)",
        type="bool",
        default=True,
    )
    parser.addini(
        "queryguard_hypopg",
        "Verify suggested indexes with the hypopg extension: auto (when "
        "installed), on (also create it inside the check's savepoint) or off",
        default="auto",
    )
    parser.addini(
        "queryguard_index_ignore_tables",
        "Tables (names or fnmatch patterns) the missing-index check ignores",
        type="linelist",
        default=[],
    )


def _threshold(config: pytest.Config, name: str) -> int:
    detail = ""
    try:
        raw: Any = config.getini(name)
    except _INI_ERRORS as exc:
        raw, detail = None, f": {exc}"
    try:
        value = 0 if isinstance(raw, bool) else int(raw)
    except (TypeError, ValueError):
        value = 0
    if value < 2:
        shown = detail or f", got {raw!r}"
        raise pytest.UsageError(f"{name} must be an integer >= 2{shown}")
    return value


def _small_repeat(config: pytest.Config, repeat: int) -> int | None:
    name = "queryguard_small_repeat_threshold"
    try:
        raw: Any = config.getini(name)
    except _INI_ERRORS as exc:
        raise pytest.UsageError(f"{name} must be 0 or an integer >= 2: {exc}") from None
    try:
        value = -1 if isinstance(raw, bool) else int(raw)
    except (TypeError, ValueError):
        value = -1
    if value == 0:
        return None
    if value < 2:
        raise pytest.UsageError(f"{name} must be 0 or an integer >= 2, got {raw!r}")
    if value >= repeat:
        raise pytest.UsageError(
            f"{name} must be lower than queryguard_repeat_threshold ({repeat}), "
            f"got {value}"
        )
    return value


def _choice(
    config: pytest.Config,
    name: str,
    choices: tuple[str, ...],
    *,
    flag: str | None = None,
) -> str:
    """Read an option with a fixed set of values; case and edge spaces are ignored.

    ``flag`` is the command-line option that overrides the ini option, if any.
    Every enum-valued option goes through here so that they agree on case.
    """
    source = name
    raw: Any = None
    if flag is not None:
        raw = config.getoption(name)
        if raw is not None:
            source = flag
    if raw is None:
        try:
            raw = config.getini(name)
        except _INI_ERRORS as exc:
            # pytest 9 rejects a non-string value from native TOML on its own.
            raise pytest.UsageError(
                f"{name} must be one of {', '.join(choices)}: {exc}"
            ) from None
    value = str(raw).strip().lower()
    if value not in choices:
        raise pytest.UsageError(
            f"{source} must be one of {', '.join(choices)}, got {raw!r}"
        )
    return value


def _optional_choice(
    config: pytest.Config, name: str, choices: tuple[str, ...]
) -> str | None:
    """Like ``_choice()``, for an option without a default: None when it is unset."""
    with contextlib.suppress(*_INI_ERRORS):  # _choice() reports these
        if config.getini(name) is None:
            return None
    return _choice(config, name, choices)


def _scope(config: pytest.Config) -> str:
    """queryguard_scope, or its deprecated name queryguard_repeat_scope."""
    new = _optional_choice(config, "queryguard_scope", SCOPES)
    old = _optional_choice(config, "queryguard_repeat_scope", SCOPES)
    if new is not None and old is not None and new != old:
        raise pytest.UsageError(
            f"queryguard_scope = {new} and its deprecated name "
            f"queryguard_repeat_scope = {old} disagree; keep only queryguard_scope"
        )
    return new or old or SCOPE_TEST


def _warn_deprecated_options(config: pytest.Config) -> None:
    """Warn once per run (not once per xdist worker) about deprecated ini names."""
    if _is_worker(config):
        return
    try:
        old = config.getini("queryguard_repeat_scope")
    except _INI_ERRORS:
        return  # _read_settings() reports the bad value
    if old is not None:
        config.issue_config_time_warning(
            QueryGuardDeprecationWarning(
                "queryguard_repeat_scope is deprecated and will be removed in "
                f"pytest-queryguard {REMOVED_IN}; rename it to queryguard_scope"
            ),
            stacklevel=2,
        )


def _write_loop(config: pytest.Config) -> int | None:
    name = "queryguard_write_loop_threshold"
    try:
        raw: Any = config.getini(name)
    except _INI_ERRORS as exc:
        raise pytest.UsageError(f"{name} must be 0 or an integer >= 2: {exc}") from None
    try:
        value = -1 if isinstance(raw, bool) else int(raw)
    except (TypeError, ValueError):
        value = -1
    if value == 0:
        return None
    if value < 2:
        raise pytest.UsageError(f"{name} must be 0 or an integer >= 2, got {raw!r}")
    return value


def _fail_on(config: pytest.Config) -> tuple[str, ...]:
    name = "queryguard_fail_on"
    try:
        raw: Any = config.getini(name)
    except _INI_ERRORS as exc:
        raise pytest.UsageError(f"{name} must be a list of kinds: {exc}") from None
    if not isinstance(raw, list) or not all(isinstance(k, str) for k in raw):
        raise pytest.UsageError(f"{name} must be a list of kinds, got {raw!r}")
    kinds = tuple(k.strip() for k in raw if k.strip() and not k.strip().startswith("#"))
    for kind in kinds:
        try:
            check_kind(kind)
        except ValueError as exc:
            raise pytest.UsageError(f"{name}: {exc}") from None
    return kinds


def _max_events(config: pytest.Config) -> int | None:
    name = "queryguard_max_events"
    try:
        raw: Any = config.getini(name)
    except _INI_ERRORS as exc:
        raise pytest.UsageError(f"{name} must be an integer >= 0: {exc}") from None
    try:
        value = -1 if isinstance(raw, bool) else int(raw)
    except (TypeError, ValueError):
        value = -1
    if value < 0:
        raise pytest.UsageError(f"{name} must be an integer >= 0, got {raw!r}")
    return value or None


def _stack_depth(config: pytest.Config) -> int:
    name = "queryguard_stack_depth"
    try:
        raw: Any = config.getini(name)
    except _INI_ERRORS as exc:
        raise pytest.UsageError(f"{name} must be an integer >= 0: {exc}") from None
    try:
        value = -1 if isinstance(raw, bool) else int(raw)
    except (TypeError, ValueError):
        value = -1
    if value < 0:
        raise pytest.UsageError(f"{name} must be an integer >= 0, got {raw!r}")
    return value


def _ignore_rules(config: pytest.Config) -> tuple[IgnoreRule, ...]:
    name = "queryguard_ignore"
    try:
        raw: Any = config.getini(name)
    except _INI_ERRORS as exc:
        raise pytest.UsageError(f"{name} must be a list of patterns: {exc}") from None
    if not isinstance(raw, list) or not all(isinstance(line, str) for line in raw):
        raise pytest.UsageError(f"{name} must be a list of patterns, got {raw!r}")
    try:
        return parse_rules(raw)
    except ValueError as exc:
        raise pytest.UsageError(f"{name}: {exc}") from None


def _strict(config: pytest.Config) -> bool:
    return _flag(config, "queryguard_strict")


def _flag(config: pytest.Config, name: str) -> bool:
    """A bool ini option that its flags (same dest) turn on or off for the run.

    The ini value is checked even when a flag overrides it; of the two flags
    the last one wins.
    """
    try:
        raw: Any = config.getini(name)
    except _INI_ERRORS as exc:
        raise pytest.UsageError(f"{name} must be true or false: {exc}") from None
    if not isinstance(raw, bool):
        raise pytest.UsageError(f"{name} must be true or false, got {raw!r}")
    cli: bool | None = config.getoption(name)
    return raw if cli is None else cli


def _strict_hook(
    item: pytest.Item, settings: _Settings
) -> (
    Callable[[RelationshipLoadEvent, CallSite | None, int, bool], BaseException | None]
    | None
):
    """The strict-mode check of this test, or None when it cannot raise.

    It raises only what would fail the test anyway: an N+1 that no
    allow_nplusone marker, queryguard_ignore pattern or baseline entry covers.
    """
    if not settings.strict or not settings.fails(KIND_RELATIONSHIP):
        return None
    if settings.update_baseline:
        return None  # the update records the N+1s; raising would stop the loop
    ignore_all, marker_rules = _nplusone_ignores(item)
    if ignore_all:
        return None
    rules = (*settings.ignore, *marker_rules)
    root = item.config.rootpath

    def check(
        load: RelationshipLoadEvent,
        first: CallSite | None,
        parents: int,
        other_lines: bool,
    ) -> BaseException | None:
        # the finding the report would make: located at the relationship's
        # first lazy load, so ignore patterns and baseline entries match it the
        # same way; with parents of other lines too it has no patch
        parent = load.parent
        detection = RelationshipFinding(
            load.relationship,
            parents,
            first,
            None,
            scalar=load.scalar,
            parent_site=None if parent is None else parent.callsite,
            other_parent_sites=1 if other_lines else 0,
            parent_root=None if parent is None else parent.root,
            parent_path=() if parent is None else parent.path,
            orm=load.orm,
        )
        finding = make_finding(detection, cwd=root)
        if rules and not apply_rules([finding], rules)[0]:
            return None
        if settings.baseline and not baselines.split([finding], settings.baseline)[0]:
            return None
        if settings.show_patch:
            # the exception replaces the report, so it carries the patch too
            finding = _with_fix(finding, detection, root, settings.started)
        error = NPlusOneDetected(
            format_strict(finding, parents, patch=settings.show_patch)
        )
        error._queryguard_strict = True  # type: ignore[attr-defined]
        return error

    return check


def _test_code_mode(config: pytest.Config) -> str:
    return _choice(config, "queryguard_test_code", _EAGER_MODES)


def _cartesian_mode(config: pytest.Config) -> str:
    return _choice(config, "queryguard_cartesian_load", _EAGER_MODES)


def _unused_eager(config: pytest.Config) -> str:
    return _choice(config, "queryguard_unused_eager_load", _EAGER_MODES)


def _unused_columns(config: pytest.Config) -> str:
    return _choice(config, "queryguard_unused_columns", _EAGER_MODES)


def _index_check(config: pytest.Config) -> bool:
    return _flag(config, "queryguard_index_check")


def _index_advisor(config: pytest.Config) -> bool:
    name = "queryguard_index_advisor"
    try:
        raw: Any = config.getini(name)
    except _INI_ERRORS as exc:
        raise pytest.UsageError(f"{name} must be true or false: {exc}") from None
    if not isinstance(raw, bool):
        raise pytest.UsageError(f"{name} must be true or false, got {raw!r}")
    return raw


def _hypopg(config: pytest.Config) -> str:
    return _choice(config, "queryguard_hypopg", tuple(hypopg.MODES))


def _ignore_tables(config: pytest.Config) -> tuple[str, ...]:
    name = "queryguard_index_ignore_tables"
    try:
        raw: Any = config.getini(name)
    except _INI_ERRORS as exc:
        raise pytest.UsageError(
            f"{name} must be a list of table names: {exc}"
        ) from None
    if not isinstance(raw, list) or not all(isinstance(t, str) and t for t in raw):
        raise pytest.UsageError(f"{name} must be a list of table names, got {raw!r}")
    return tuple(raw)


def _baseline_path(config: pytest.Config) -> Path | None:
    cli: str | None = config.getoption("queryguard_baseline")
    if cli is not None:
        if not cli.strip():
            raise pytest.UsageError("--queryguard-baseline needs a path")
        return Path(config.invocation_params.dir, cli.strip())
    name = "queryguard_baseline"
    try:
        raw: Any = config.getini(name)
    except _INI_ERRORS as exc:
        raise pytest.UsageError(f"{name} must be a path: {exc}") from None
    if not isinstance(raw, str):
        raise pytest.UsageError(f"{name} must be a path, got {raw!r}")
    return Path(config.rootpath, raw.strip()) if raw.strip() else None


def _budgets_path(config: pytest.Config) -> Path | None:
    path = _output_path(config, "queryguard_budgets", "--queryguard-budgets")
    if path is not None:
        return path
    name = "queryguard_budgets"
    try:
        raw: Any = config.getini(name)
    except _INI_ERRORS as exc:
        raise pytest.UsageError(f"{name} must be a path: {exc}") from None
    if not isinstance(raw, str):
        raise pytest.UsageError(f"{name} must be a path, got {raw!r}")
    return Path(config.rootpath, raw.strip()) if raw.strip() else None


def _default_budget(config: pytest.Config) -> int | None:
    name = "queryguard_max_queries"
    try:
        raw: Any = config.getini(name)
    except _INI_ERRORS as exc:
        raise pytest.UsageError(f"{name} must be an integer >= 0: {exc}") from None
    if isinstance(raw, str) and not raw.strip():
        return None
    try:
        value = -1 if isinstance(raw, bool) else int(raw)
    except (TypeError, ValueError):
        value = -1
    if value < 0:
        raise pytest.UsageError(f"{name} must be an integer >= 0, got {raw!r}")
    return value


def _route_budgets(config: pytest.Config) -> tuple[dict[str, int], int | None]:
    """(patterns, default) of the ini file's route budgets."""
    try:
        lines: Any = config.getini(routes.INI_BUDGETS)
        raw: Any = config.getini(routes.INI_DEFAULT)
    except _INI_ERRORS as exc:
        raise pytest.UsageError(f"queryguard route budgets: {exc}") from None
    if isinstance(lines, str):
        lines = lines.splitlines()
    try:
        return routes.parse_lines(lines), routes.parse_default(raw)
    except (TypeError, ValueError) as exc:
        raise pytest.UsageError(f"{routes.INI_BUDGETS}: {exc}") from None


def _route_config(item: pytest.Item, settings: _Settings) -> routes.RouteBudgets | None:
    """The route budgets of the test, None without any; a bad marker fails it."""
    marker = item.get_closest_marker(routes.MARKER)
    if marker is None:
        if not settings.route_budgets and settings.route_default is None:
            return None
        return routes.RouteBudgets(dict(settings.route_budgets), settings.route_default)
    try:
        found = routes.from_marker(
            marker, item.nodeid, settings.route_budgets, settings.route_default
        )
    except ValueError as exc:
        pytest.fail(str(exc), pytrace=False)
    if not found.budgets and found.default is None:
        return None
    return found


def _output_path(config: pytest.Config, dest: str, flag: str) -> Path | None:
    """The path of an output file option, relative to the invocation directory."""
    raw: str | None = config.getoption(dest)
    if raw is None:
        return None
    if not raw.strip():
        raise pytest.UsageError(f"{flag} needs a path")
    path = Path(config.invocation_params.dir, raw.strip())
    setattr(config.option, dest, str(path))  # workers get the resolved path
    return path


def _sarif_path(config: pytest.Config) -> Path | None:
    return _output_path(config, "queryguard_sarif", "--queryguard-sarif")


def _json_path(config: pytest.Config) -> Path | None:
    return _output_path(config, "queryguard_json", "--queryguard-json")


def _patch_path(config: pytest.Config) -> Path | None:
    return _output_path(config, "queryguard_write_patch", "--queryguard-write-patch")


def _shown(path: Path, root: Path | None) -> str:
    """A path for the terminal: relative to the rootdir when inside it, as in findings."""
    return _display_path(os.path.normpath(path), root)


def _file_error(exc: Exception, path: Path, root: Path | None) -> str:
    """The text of an error about ``path``, with the path as ``_shown()`` prints it."""
    # the messages are built with f"{path}", so this is the spelling to replace
    return str(exc).replace(str(path), _shown(path, root))


def _read_settings(config: pytest.Config) -> _Settings:
    mode = _choice(config, "queryguard_mode", _MODES, flag="--queryguard-mode")
    repeat = _threshold(config, "queryguard_repeat_threshold")
    baseline_path = _baseline_path(config)
    update = bool(config.getoption("queryguard_update_baseline"))
    baseline: frozenset[Identity] | None = None
    previous_error: str | None = None
    if update and baseline_path is None:
        raise pytest.UsageError(
            "--queryguard-update-baseline needs a baseline file: pass "
            "--queryguard-baseline=PATH or set queryguard_baseline"
        )
    if update and mode == "off":
        raise pytest.UsageError(
            "--queryguard-update-baseline cannot run with measurement off "
            "(the queryguard mode is off)"
        )
    if baseline_path is not None:
        try:
            baseline = baselines.load(baseline_path)
        except BaselineError as exc:
            if not update:
                raise pytest.UsageError(
                    f"queryguard baseline: {_file_error(exc, baseline_path, config.rootpath)}"
                ) from None
            # an update replaces a missing or unreadable file
            baseline = frozenset()
            if baseline_path.exists():
                previous_error = _file_error(exc, baseline_path, config.rootpath)
        # the CLI path is relative to the invocation directory; workers resolve
        # the same file, whatever their own working directory is
        config.option.queryguard_baseline = str(baseline_path)
    settings = _Settings(
        mode,
        _threshold(config, "queryguard_relationship_threshold"),
        repeat,
        _index_check(config),
        _ignore_tables(config),
        _max_events(config),
        _ignore_rules(config),
        _threshold(config, "queryguard_column_load_threshold"),
        _small_repeat(config, repeat),
        _fail_on(config),
        _write_loop(config),
        _unused_eager(config),
        baseline_path,
        update,
        baseline,
        _sarif_path(config),
        _index_advisor(config),
        _hypopg(config),
        _scope(config),
    )
    settings.baseline_previous_error = previous_error
    settings.rootpath = config.rootpath
    settings.json_path = _json_path(config)
    settings.show_patch = _flag(config, "queryguard_show_patch")
    settings.patch_path = _patch_path(config)
    settings.cartesian = _cartesian_mode(config)
    settings.test_code = _test_code_mode(config)
    settings.unused_columns = _unused_columns(config)
    settings.strict = _strict(config)
    settings.default_budget = _default_budget(config)
    settings.route_budgets, settings.route_default = _route_budgets(config)
    settings.budgets_path = _budgets_path(config)
    settings.update_budgets = bool(config.getoption("queryguard_update_budgets"))
    if settings.update_budgets and mode == "off":
        raise pytest.UsageError(
            "--queryguard-update-budgets cannot run with measurement off "
            "(the queryguard mode is off)"
        )
    if settings.update_budgets and settings.budgets_path is None:
        raise pytest.UsageError(
            "--queryguard-update-budgets needs a budget file: pass "
            "--queryguard-budgets=PATH or set queryguard_budgets"
        )
    if settings.budgets_path is not None:
        try:
            settings.budgets = budget_files.load(settings.budgets_path)
        except budget_files.BudgetFileError as exc:
            if not settings.update_budgets:
                raise pytest.UsageError(
                    "queryguard budgets: "
                    f"{_file_error(exc, settings.budgets_path, config.rootpath)}"
                ) from None
            # an update replaces a missing file; a broken one is reported
            settings.budgets = {}
            if settings.budgets_path.exists():
                settings.budgets_previous_error = _file_error(
                    exc, settings.budgets_path, config.rootpath
                )
    return settings


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line(
        "markers",
        "max_queries(limit): fail the test if it runs more than limit SQL statements.",
    )
    config.addinivalue_line(
        "markers",
        "queryguard_max_queries(limit): max_queries under a name no other plugin "
        "reads; it wins over max_queries.",
    )
    config.addinivalue_line(
        "markers",
        "max_db_time(seconds): fail the test if its SQL statements take more "
        "than that many seconds in total.",
    )
    config.addinivalue_line(
        "markers",
        "queryguard_max_db_time(seconds): max_db_time under a name no other "
        "plugin reads; it wins over max_db_time.",
    )
    config.addinivalue_line(
        "markers",
        "queryguard_ignore(*labels, kind=..., file=..., function=..., stack=...): "
        "do not report N+1 query findings for this test; with arguments, only "
        "the findings they match (fnmatch patterns).",
    )
    config.addinivalue_line(
        "markers",
        "allow_nplusone(*labels, kind=..., file=..., function=..., stack=...): "
        "the same as queryguard_ignore.",
    )
    config.addinivalue_line(
        "markers",
        "queryguard_route_budgets(budgets, default=...): EXPERIMENTAL: the most "
        "SQL statements one request of a route may run in this test, as a "
        'mapping {"GET /books/{id}": 5}; checked before queryguard_route_budgets '
        "of the ini file; default= replaces queryguard_route_default_budget.",
    )
    config.addinivalue_line(
        "markers",
        "allow_missing_index(*tables): skip the missing-index check for this "
        "test, or only for the given tables.",
    )
    config.stash[_outer_error] = swap_error(None)
    # outside the guard below: with -W error the warning is raised on purpose
    _warn_deprecated_options(config)
    try:
        _configure(config)
    except pytest.UsageError:
        raise
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        # Measurement stays off; the terminal summary says so.
        record_error(exc, "pytest_configure")


def _configure(config: pytest.Config) -> None:
    if config.pluginmanager.has_plugin("pytester"):
        # pytester's in-process sessions unload the modules they import; the
        # compiled modules of SQLAlchemy cannot be imported a second time, so
        # it is imported here, outside them, as before SQLAlchemy was loaded
        # only when the project imports it (backends._sqlalchemy).
        with contextlib.suppress(ImportError):
            importlib.import_module("sqlalchemy.orm")
    config.stash[_outer_stopped] = indexes.swap_stopped(None)
    config.stash[_outer_catalog_error] = indexes.swap_catalog_error(None)
    config.stash[_outer_no_plpgsql] = indexes.swap_no_plpgsql(indexes.EngineSet())
    config.stash[_outer_root] = swap_root(config.rootpath)
    test_code = config.stash[_test_code] = TestCode(str(config.rootpath))
    config.stash[_outer_test_code] = swap_test_code(test_code)
    # A nested session (pytester) may change the database; start afresh.
    catalog.reset()
    settings = _read_settings(config)
    # the calls into the application, for the test-code split (detectors._driven)
    config.stash[_outer_track_calls] = set_track_calls(settings.test_code != "fail")
    config.stash[_outer_stack_depth] = swap_stack_depth(_stack_depth(config))
    config.stash[_settings] = settings
    _active.append(settings)
    # every run: the stale lists also need to know (an xdist run goes on)
    config.pluginmanager.register(
        _CollectionErrors(settings), "queryguard-collection-errors"
    )
    if config.getoption("queryguard_report"):
        config.stash[_report] = []
    if settings.mode != "off":
        install()
        if settings.index_check:
            install_index_check()
        if settings.unused_eager != "off":
            config.stash[_eager_enabled] = True  # set first: undone even if it fails
            _sqlalchemy_check("eager").enable()
        if settings.unused_columns != "off":
            config.stash[_columns_enabled] = True  # set first: undone even if it fails
            _sqlalchemy_check("unused_columns").enable()
        if settings.cartesian != "off":
            config.stash[_cartesian_enabled] = True
            enable_cartesian()
        if settings.strict:
            # a do_orm_execute listener, so it raises before the engine runs
            config.stash[_strict_enabled] = True
            enable_strict()


class _CollectionErrors:
    """Notes a collection error, also one that a pytest-xdist worker reports."""

    def __init__(self, settings: _Settings) -> None:
        self._settings = settings

    def pytest_collectreport(self, report: pytest.CollectReport) -> None:
        try:
            if report.failed:
                self._settings.collection_failed = True
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            record_error(exc, "collection report")


# The settings of the configured sessions, innermost last (pytester nests one
# in the process): for hooks that get no config, such as pytest_runtest_logreport.
_active: list[_Settings] = []


def pytest_unconfigure(config: pytest.Config) -> None:
    stash = config.stash
    settings = stash.get(_settings, None)
    if settings is not None and settings in _active:
        _active.remove(settings)
    # Every step runs, so a nested session (pytester) always gives the outer
    # session its state back.
    steps: tuple[Callable[[], object], ...] = (
        lambda: _disable_eager(config),
        lambda: _disable_columns(config),
        lambda: _disable_cartesian(config),
        lambda: _disable_strict(config),
        lambda: swap_error(stash.get(_outer_error, None)),
        lambda: indexes.swap_stopped(stash.get(_outer_stopped, None)),
        lambda: indexes.swap_catalog_error(stash.get(_outer_catalog_error, None)),
        lambda: indexes.swap_no_plpgsql(
            stash.get(_outer_no_plpgsql, indexes.EngineSet())
        ),
        lambda: swap_root(stash.get(_outer_root, None)),
        lambda: _restore_test_code(config),
        lambda: _restore_stack_depth(config),
        catalog.reset,
    )
    for step in steps:
        try:
            step()
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            # After the summary: printed by Python's default warning handler.
            warn_internal(
                QueryGuardInternalWarning(
                    f"pytest-queryguard could not clean up after the session: {exc!r}"
                )
            )


def _restore_test_code(config: pytest.Config) -> None:
    if _outer_test_code in config.stash:
        swap_test_code(config.stash[_outer_test_code])
        del config.stash[_outer_test_code]
    if _outer_track_calls in config.stash:
        set_track_calls(config.stash[_outer_track_calls])
        del config.stash[_outer_track_calls]


def _restore_stack_depth(config: pytest.Config) -> None:
    if _outer_stack_depth in config.stash:
        swap_stack_depth(config.stash[_outer_stack_depth])
        del config.stash[_outer_stack_depth]


def _disable_cartesian(config: pytest.Config) -> None:
    if config.stash.get(_cartesian_enabled, False):
        config.stash[_cartesian_enabled] = False
        disable_cartesian()


def _disable_strict(config: pytest.Config) -> None:
    if config.stash.get(_strict_enabled, False):
        config.stash[_strict_enabled] = False
        disable_strict()


def _disable_columns(config: pytest.Config) -> None:
    if config.stash.get(_columns_enabled, False):
        config.stash[_columns_enabled] = False
        _sqlalchemy_check("unused_columns").disable()


def _disable_eager(config: pytest.Config) -> None:
    if config.stash.get(_eager_enabled, False):
        config.stash[_eager_enabled] = False
        _sqlalchemy_check("eager").disable()


def _report_internal_error(config: pytest.Config) -> None:
    error = internal_error()
    if error is None or config.stash.get(_internal_reported, False):
        return
    config.stash[_internal_reported] = True
    failure = internal_failure()
    where = f" ({failure.source})" if failure is not None else ""
    warn_internal(
        QueryGuardInternalWarning(
            f"pytest-queryguard disabled itself after an internal error: {error!r}"
            f"{where}"
        )
    )


def _write_internal_failure(terminalreporter: pytest.TerminalReporter) -> None:
    """Tell the user, once, that measurement stopped, where and why."""
    config = terminalreporter.config
    failure = internal_failure()
    if failure is None or config.stash.get(_failure_summarised, False):
        return
    config.stash[_failure_summarised] = True
    terminalreporter.write_sep("=", "queryguard: measurement stopped", yellow=True)
    for line in format_failure(failure):
        terminalreporter.write_line(line)


# queryguard_ignore and its permanent alias allow_nplusone mean the same.
_IGNORE_MARKERS = ("queryguard_ignore", "allow_nplusone")


def _nplusone_ignores(item: pytest.Item) -> tuple[bool, tuple[IgnoreRule, ...]]:
    """(ignore every N+1 finding, rules) from queryguard_ignore markers."""
    ignore_all, named = _named_ignores(item)
    return ignore_all, tuple(rule for _, rule in named)


def _named_ignores(
    item: pytest.Item,
) -> tuple[bool, tuple[tuple[str, IgnoreRule], ...]]:
    """(ignore every N+1 finding, (marker name, rule) pairs) of the test."""
    ignore_all = False
    rules: list[tuple[str, IgnoreRule]] = []
    for name in _IGNORE_MARKERS:
        for marker in item.iter_markers(name):
            patterns = marker.args
            extra = set(marker.kwargs) - {"kind", "file", "function", "stack"}
            values = [*patterns, *marker.kwargs.values()]
            if extra or not all(isinstance(v, str) and v for v in values):
                pytest.fail(
                    f"{name} on {item.nodeid} takes label patterns and the "
                    "keywords kind, file, function and stack, all as strings, got "
                    f"{marker.args!r} {marker.kwargs!r}",
                    pytrace=False,
                )
            if not marker.args and not marker.kwargs:
                ignore_all = True
                continue
            kind = marker.kwargs.get("kind", "*")
            try:
                check_kind(kind)
            except ValueError as exc:
                pytest.fail(f"{name} on {item.nodeid}: {exc}", pytrace=False)
            for label in patterns or ("*",):
                rule = IgnoreRule(
                    kind,
                    label,
                    marker.kwargs.get("file"),
                    marker.kwargs.get("function"),
                    marker.kwargs.get("stack"),
                )
                rules.append((name, rule))
    return ignore_all, tuple(rules)


def _fails(settings: _Settings, finding: Finding) -> bool:
    """True when the finding fails the test; else it is only a warning."""
    if finding.test_code and settings.test_code != "fail":
        return False
    if finding.kind == KIND_UNUSED_EAGER_LOAD and settings.unused_eager != "fail":
        return False
    if finding.kind == KIND_CARTESIAN_LOAD and settings.cartesian != "fail":
        return False
    if finding.kind == KIND_UNUSED_COLUMNS and settings.unused_columns != "fail":
        return False
    return settings.fails(finding.kind)


def _analyse(
    item: pytest.Item,
    collector: QueryCollector,
    settings: _Settings,
    trackers: _Trackers,
    sieve: blocks.Sieve | None = None,
) -> tuple[str | None, str | None]:
    """(report of the failing kinds, report of the others) for the finished test.

    Either is None when empty; never raises.
    """
    if internal_error() is not None:
        return None, None
    ignore_all, marker_rules = _nplusone_ignores(item)
    if ignore_all:
        return None, None
    try:
        root = item.config.rootpath
        rules = bool(settings.ignore or marker_rules)
        blocked = sieve is not None and _in_blocks(collector, trackers)
        # with blocks, the first set only matches the patterns: no patches
        findings = _findings(
            collector, settings, trackers, root, None, fixes=not blocked
        )
        if blocked:
            # The patterns and markers are matched against what the test found
            # without the blocks, so one that a block also covers is not stale.
            if rules:
                _drop_ignored(item, settings, findings, marker_rules)
            findings = _findings(collector, settings, trackers, root, sieve)
            if rules:
                findings = apply_rules(findings, (*settings.ignore, *marker_rules))[0]
        elif rules:
            findings = _drop_ignored(item, settings, findings, marker_rules)
        if settings.test_code == "off":
            findings = _leave_out_test_code(settings, findings, item.nodeid)
        _note_found(settings, findings, item.nodeid)
        findings = _apply_baseline(settings, findings, item)
        finding_groups.add(settings.groups, findings, item.nodeid)
        failing = [f for f in findings if _fails(settings, f)]
        warning = [f for f in findings if not _fails(settings, f)]
        note = ""
        if collector.truncated and settings.max_events is not None:
            note = "\n\n" + format_truncation(settings.max_events)
        return (
            format_findings(failing, cwd=root, patches=settings.show_patch) + note
            if failing
            else None,
            format_findings(warning, cwd=root, patches=settings.show_patch) + note
            if warning
            else None,
        )
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "N+1 analysis")
        return None, None


def _leave_out_test_code(
    settings: _Settings, findings: list[Finding], nodeid: str
) -> list[Finding]:
    """The findings minus those of the test code, which are only counted."""
    kept = [finding for finding in findings if not finding.test_code]
    if len(kept) < len(findings):
        settings.test_code_left_out[nodeid] = len(findings) - len(kept)
        if settings.baselining:
            # still found: a baseline entry for one is not stale, and an
            # update keeps it. One that is not in the baseline is not added:
            # the run never showed it, and with warn or fail later it must be.
            baseline = settings.baseline or frozenset()
            settings.seen.update(
                baselines.key(f)
                for f in findings
                if f.test_code and baselines.key(f) in baseline
            )
    return kept


def _findings(
    collector: QueryCollector,
    settings: _Settings,
    trackers: _Trackers,
    root: Path,
    sieve: blocks.Sieve | None,
    *,
    fixes: bool = True,
) -> list[Finding]:
    """The N+1 findings of the test; with a sieve, minus those of ignore() blocks.

    With ``fixes`` (and a patch or SARIF asked for), relationship-load
    findings get the patch of their parent query when it is certain.
    """
    split = settings.test_code != "fail"
    detections = _detect(collector, settings, sieve, False if split else None)
    findings = make_findings(detections, cwd=root)
    if fixes and settings.fixing:
        # a repetition that test code drives (detectors._driven) is the test
        # code's: no patch when it is only counted
        findings = [
            finding
            if detection.driven and settings.test_code == "off"
            else _with_fix(finding, detection, root, settings.started)
            for finding, detection in zip(findings, detections, strict=True)
        ]
    if split and _has_test_code(collector):
        # the test code's own N+1s: warnings, or only counted (_analyse)
        detections = _detect(collector, settings, sieve, True)
        side = [
            replace(finding, test_code=True)
            for finding in make_findings(detections, cwd=root)
        ]
        if fixes and settings.fixing and settings.test_code == "warn":
            side = [
                _with_fix(finding, detection, root, settings.started)
                for finding, detection in zip(side, detections, strict=True)
            ]
        findings.extend(side)
    if trackers.eager is not None:
        findings.extend(
            _sqlalchemy_check("eager").findings(trackers.eager, cwd=root, sieve=sieve)
        )
    if trackers.columns is not None:
        findings.extend(
            _sqlalchemy_check("unused_columns").findings(
                trackers.columns, cwd=root, sieve=sieve
            )
        )
    if settings.cartesian != "off" and collector.cartesian_loads:
        findings.extend(
            _sqlalchemy_check("cartesian").findings(collector, cwd=root, sieve=sieve)
        )
    return findings


def _has_test_code(collector: QueryCollector) -> bool:
    """Whether any statement or load of the test ran in test code."""
    return any(
        event.test_code
        for events in (
            collector.statements,
            collector.relationship_loads,
            collector.column_loads,
        )
        for event in events
    )


def _detect(
    collector: QueryCollector,
    settings: _Settings,
    sieve: blocks.Sieve | None,
    test_code: bool | None,
) -> list[Detection]:
    """The count rules' findings: see ``detect`` for ``test_code``."""
    return detect(
        collector,
        relationship_threshold=settings.relationship,
        repeat_threshold=settings.repeat,
        column_load_threshold=settings.column_load,
        small_repeat_threshold=settings.small_repeat,
        write_loop_threshold=settings.write_loop,
        scope=settings.repeat_scope,
        sieve=sieve,
        test_code=test_code,
    )


def _with_fix(
    finding: Finding, detection: Detection, root: Path, started: float
) -> Finding:
    """The finding with the patch of its parent query, when one is certain."""
    if not isinstance(detection, RelationshipFinding):
        return finding
    try:
        fix = fixpatch.make(detection, root, started)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "making a patch")
        return finding
    return finding if fix is None else replace(finding, fix=fix)


def _in_blocks(collector: QueryCollector, trackers: _Trackers) -> bool:
    """True when some event of the test ran inside an ignore() block."""
    events: tuple[Sequence[Any], ...] = (
        collector.relationship_loads,
        collector.statements,
        collector.column_loads,
        collector.cartesian_loads,
        () if trackers.eager is None else trackers.eager.loads,
    )
    if any(event.ignores for group in events for event in group):
        return True
    columns = trackers.columns
    return columns is not None and any(
        any(group.ignores) for group in columns.groups.values()
    )


def _at_the_test(finding: Finding, item: pytest.Item) -> Finding:
    """The finding located at the test, for SARIF, when its call site is unknown.

    The call site is unknown when no application frame was on the stack, for
    example when ``session.execute`` itself is handed to a worker thread. GitHub
    shows a result only with a location, so the test stands in for it. Only
    the SARIF copy changes: the terminal text, the baseline and the ignore
    rules keep the finding as it was.
    """
    if finding.file is not None or finding.function is not None:
        return finding
    try:
        path, line, _ = item.reportinfo()
        file = item.nodeid.split("::", 1)[0]
        if not file or Path(str(path)).name != Path(file).name:
            return finding
        return replace(
            finding,
            file=file,
            function=getattr(item, "originalname", None) or item.name,
            line=(line or 0) + 1,
            message=finding.message.replace(
                "<unknown location>", "<unknown location>, reported at the test"
            ),
        )
    except Exception:  # noqa: BLE001  # a plugin bug must never break the user suite
        return finding


def _note_found(settings: _Settings, findings: list[Finding], nodeid: str) -> None:
    """Note the findings of a test after ignores, before the baseline, for the JSON."""
    if settings.json_path is not None:
        testjson.record_findings(settings.tests, nodeid, findings, settings.baseline)


def _apply_baseline(
    settings: _Settings, findings: list[Finding], item: pytest.Item
) -> list[Finding]:
    """The findings that still count: not in the baseline, and no update run.

    Records every finding it gets, for the stale-entry report and for an update.
    """
    if settings.baselining:
        settings.seen.update(baselines.key(f) for f in findings)
        if settings.update_baseline:
            findings = []
        else:
            findings = baselines.split(findings, settings.baseline or frozenset())[0]
    if settings.patch_path is not None:
        for finding in findings:
            if finding.fix is not None:
                settings.fixes[finding.fix] = None
    if settings.sarif_path is not None:
        for finding in findings:
            level = (
                sarif.LEVEL_ERROR if _fails(settings, finding) else sarif.LEVEL_WARNING
            )
            sarif.add(settings.reported, _at_the_test(finding, item), level)
    return findings


def _drop_ignored(
    item: pytest.Item,
    settings: _Settings,
    findings: list[Finding],
    marker_rules: tuple[IgnoreRule, ...],
    *,
    indexes: bool = False,
) -> list[Finding]:
    """The findings the ini patterns and the test's markers do not ignore.

    A marker pattern is stale when it matched neither an N+1 finding nor an
    index finding of the test: the N+1 pass (``indexes=False``) lists every
    unmatched pattern, the index pass then takes back those it matched.
    """
    kept, used = apply_rules(findings, (*settings.ignore, *marker_rules))
    settings.ignore_used.update(used)
    if indexes:
        settings.stale_markers[:] = [
            (nodeid, rule, name)
            for nodeid, rule, name in settings.stale_markers
            if nodeid != item.nodeid or rule not in used
        ]
    else:
        # the rules of _named_ignores() are marker_rules, with their marker
        settings.stale_markers.extend(
            (item.nodeid, rule, name)
            for name, rule in _named_ignores(item)[1]
            if rule not in used
        )
    return kept


def _index_exemption(item: pytest.Item) -> tuple[bool, tuple[str, ...]]:
    """(skip the whole check, tables to ignore) from allow_missing_index markers."""
    exempt_all = False
    tables: list[str] = []
    for marker in item.iter_markers("allow_missing_index"):
        if marker.kwargs or not all(isinstance(t, str) and t for t in marker.args):
            pytest.fail(
                f"allow_missing_index on {item.nodeid} takes table names "
                f"as strings, or nothing, got {marker.args!r} {marker.kwargs!r}",
                pytrace=False,
            )
        if not marker.args:
            exempt_all = True
        tables.extend(marker.args)
    return exempt_all, tuple(tables)


def _analyse_indexes(
    item: pytest.Item,
    collector: QueryCollector,
    settings: _Settings,
    exempt: tuple[str, ...],
    sieve: blocks.Sieve | None = None,
) -> str | None:
    """The missing-index report for the finished test, or None; never raises."""
    if internal_error() is not None or not collector.scans:
        return None
    _, marker_rules = _nplusone_ignores(item)
    try:
        root = item.config.rootpath
        scans = select_findings(collector.scans, (*settings.ignore_tables, *exempt))
        if not scans:
            return None
        findings = [make_index_finding(scan, cwd=root) for scan in scans]
        kept = findings
        if settings.ignore or marker_rules:
            kept = _drop_ignored(item, settings, kept, marker_rules, indexes=True)
        if sieve is not None:
            # after the patterns, which are matched (and credited) on all
            blocked = _blocked_scans(collector, scans, sieve)
            if blocked:
                kept = [
                    finding
                    for scan, finding in zip(scans, findings, strict=True)
                    if id(scan) not in blocked and any(f is finding for f in kept)
                ]
        _note_found(settings, kept, item.nodeid)
        if settings.baselining or settings.sarif_path:
            kept = _apply_baseline(settings, kept, item)
        if not kept:
            return None
        finding_groups.add(settings.groups, kept, item.nodeid)
        keep_ids = {id(f) for f in kept}
        scans = [
            scan
            for scan, finding in zip(scans, findings, strict=True)
            if id(finding) in keep_ids
        ]
        return format_index_findings(scans, cwd=root)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "missing-index analysis")
        return None


def _blocked_scans(
    collector: QueryCollector, selected: list[ScanEvent], sieve: blocks.Sieve
) -> set[int]:
    """The ids of the selected scans whose every run was inside ignore() blocks.

    A statement is explained at its first run only; ``index_runs`` holds the
    blocks of its later runs (see ``QueryCollector.runs_of``).
    """
    if not any(scan.ignores for scan in collector.scans):
        return set()
    runs: dict[tuple[object, ...], list[tuple[blocks.IgnoreBlock, ...]]] = {}
    for scan in collector.scans:
        later = collector.runs_of(scan)
        runs.setdefault(scan_key(scan.issue), []).extend(
            [scan.ignores] if later is None else later
        )
    found: set[int] = set()
    for scan in selected:
        hidden = blocks.covering_tags(runs[scan_key(scan.issue)], KIND_MISSING_INDEX)
        if hidden:
            sieve.note(hidden)
            found.add(id(scan))
    return found


def _note_blocks(
    item: pytest.Item,
    settings: _Settings,
    sieve: blocks.Sieve,
    collector: QueryCollector,
    kinds: tuple[str, ...],
    *,
    stopped: bool = False,
) -> None:
    """Note the ignore() blocks of the test, for the stale-block report.

    A block is stale when no test that entered it left out a finding with it,
    in the plugin's analysis or in a check run in the test (``blocks_used``).
    Not noted as entered: blocks of a test whose analysis did not run (an
    internal error, a bare allow_nplusone marker) or stopped storing events,
    blocks for kinds the test did not look for (``kinds``): they could
    not have left anything out, and blocks of a test queryguard_strict
    stopped (``stopped``): they may be for a finding after the access, which
    the test never reached, as for a test that failed on its own.
    """
    if internal_error() is not None:
        return
    root = item.config.rootpath
    with blocks.lock:
        used = (*sieve.used, *(collector.blocks_used or ()))
    for block in used:
        where = _block_site(block, root)
        if where is not None:
            settings.blocks_used.add(where)
    if stopped or _nplusone_ignores(item)[0]:
        return
    for block in list(collector.blocks_entered.values()):
        if not any(block.matches(kind) for kind in kinds):
            continue
        where = _block_site(block, root)
        if where is not None:
            settings.blocks_entered.setdefault(where, block.describe())


def _analysed_kinds(
    settings: _Settings, collector: QueryCollector, trackers: _Trackers
) -> tuple[str, ...]:
    """The finding kinds the test was checked for; none past the event cap."""
    if collector.truncated:
        return ()  # the blocks do not apply then (see detectors.detect)
    kinds = [KIND_RELATIONSHIP, KIND_REPEAT, KIND_COLUMN_LOAD]
    if settings.write_loop is not None:
        kinds.append(KIND_WRITE_LOOP)
    if trackers.eager is not None:
        kinds.append(KIND_UNUSED_EAGER_LOAD)
    if trackers.columns is not None:
        kinds.append(KIND_UNUSED_COLUMNS)
    if settings.cartesian != "off":
        kinds.append(KIND_CARTESIAN_LOAD)
    if collector.index_check:
        kinds.append(KIND_MISSING_INDEX)
    return tuple(kinds)


def _block_site(block: blocks.IgnoreBlock, root: Path) -> str | None:
    site = block.site
    if site is None:
        return None
    return f"{_display_path(site.filename, root)}:{site.lineno}"


def _note_index_check(config: pytest.Config, collector: QueryCollector) -> None:
    """Add what the index check skipped in this test to the session summary."""
    if not collector.index_check:
        return
    notes = config.stash.setdefault(_index_notes, _IndexNotes())
    notes.notices.update(collector.index_notices)
    notes.partial_skipped.extend(collector.partial_skipped)
    for error in collector.explain_errors:
        notes.errors += 1
        if notes.first_error is None:
            notes.first_error = error


def _budget_marker(item: pytest.Item, name: str) -> tuple[str, pytest.Mark] | None:
    """(name, marker) of the closest ``queryguard_<name>`` or ``<name>``, or None.

    ``max_queries`` is also a marker of pytest-querycount; the prefixed name is
    read by this plugin only, so it wins when one node (the function, the
    class, the module) has both. A closer marker wins over a broader one,
    whatever its spelling.
    """
    names = (f"queryguard_{name}", name)
    closest: tuple[str, pytest.Mark] | None = None
    closest_node = None
    for node, marker in item.iter_markers_with_node():
        if marker.name not in names:
            continue
        if closest is None:
            closest, closest_node = (marker.name, marker), node
        elif node is not closest_node:
            break
        if marker.name == names[0]:
            return marker.name, marker
    return closest


def _budget(item: pytest.Item) -> int | None:
    found = _budget_marker(item, "max_queries")
    if found is None:
        return None
    name, marker = found
    if len(marker.args) > 1 or set(marker.kwargs) - {"limit", "n"}:
        pytest.fail(
            f"{name} on {item.nodeid} takes a single argument, the limit",
            pytrace=False,
        )
    keywords = [key for key in ("limit", "n") if key in marker.kwargs]
    if len(marker.args) + len(keywords) > 1:
        pytest.fail(
            f"{name} on {item.nodeid} got the limit more than once "
            "(positionally, as limit= or as n=)",
            pytrace=False,
        )
    limit = marker.kwargs[keywords[0]] if keywords else None
    if marker.args:
        limit = marker.args[0]
    if isinstance(limit, bool) or not isinstance(limit, int) or limit < 0:
        pytest.fail(
            f"{name} on {item.nodeid} needs a non-negative integer "
            f"as its limit, got {limit!r}",
            pytrace=False,
        )
    return limit


def _warn_deprecated_markers(item: pytest.Item) -> None:
    """Warn about ``max_queries(n=...)``, the spelling of 0.1 to 0.3.

    Outside the guard of the measurement: with -W error the warning fails the
    test, as a deprecation should, instead of being taken for a plugin bug.
    """
    found = _budget_marker(item, "max_queries")
    # n= is how pytest-querycount spells its limit: no warning when it reads
    # the marker too
    querycount = item.config.pluginmanager.has_plugin("querycount")
    if found is not None and "n" in found[1].kwargs and not querycount:
        item.warn(
            QueryGuardDeprecationWarning(
                f"{found[0]}(n=...) is deprecated and will be removed in "
                f"pytest-queryguard {REMOVED_IN}; pass the limit positionally, "
                f"{found[0]}({found[1].kwargs['n']!r}), or as limit="
            )
        )


def _other_budget(
    item: pytest.Item, settings: _Settings
) -> tuple[int | None, str | None]:
    """(limit, where it comes from) for a test without a max_queries marker.

    The budget file first, then queryguard_max_queries. While the file is being
    updated neither applies: the run records the counts and writes them.
    """
    if settings.update_budgets:
        return None, None
    if item.nodeid in settings.budgets:
        name = settings.budgets_path.name if settings.budgets_path else "budget file"
        return settings.budgets[item.nodeid], (
            f"the budget of this test in {name}; if the new count is right, "
            "update it with --queryguard-update-budgets"
        )
    if settings.default_budget is not None:
        return settings.default_budget, (
            "the queryguard_max_queries ini option, the default budget of tests "
            "without a marker"
        )
    return None, None


def _time_budget(item: pytest.Item) -> float | None:
    found = _budget_marker(item, "max_db_time")
    if found is None:
        return None
    name, marker = found
    if len(marker.args) > 1 or set(marker.kwargs) - {"seconds"}:
        pytest.fail(
            f"{name} on {item.nodeid} takes a single argument, the limit in seconds",
            pytrace=False,
        )
    if marker.args and "seconds" in marker.kwargs:
        pytest.fail(
            f"{name} on {item.nodeid} got the limit twice, positionally "
            "and as seconds=",
            pytrace=False,
        )
    limit = marker.args[0] if marker.args else marker.kwargs.get("seconds")
    if (
        isinstance(limit, bool)
        or not isinstance(limit, (int, float))
        or not limit >= 0
        or limit == float("inf")
    ):
        pytest.fail(
            f"{name} on {item.nodeid} needs a non-negative number of "
            f"seconds as its limit, got {limit!r}",
            pytrace=False,
        )
    return float(limit)


def _time_budget_report(
    item: pytest.Item, collector: QueryCollector, limit: float
) -> str | None:
    """The database-time failure text, or None; a bug here never fails the test."""
    try:
        if collector.db_time <= limit:
            return None
        return format_time_budget(
            limit,
            collector.statements,
            cwd=item.config.rootpath,
            total=collector.statement_count,
            db_time=collector.db_time,
        )
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "database-time budget report")
        return None


def _budget_texts(
    item: pytest.Item,
    collector: QueryCollector,
    limit: int | None,
    time_limit: float | None,
    source: str | None,
) -> list[str]:
    """The failure texts of the test's query and database-time budgets."""
    texts: list[str] = []
    if limit is not None:
        budget = _budget_report(item, collector, limit, source)
        if budget is not None:
            texts.append(budget)
    if time_limit is not None:
        time_budget = _time_budget_report(item, collector, time_limit)
        if time_budget is not None:
            texts.append(time_budget)
    return texts


def _budget_report(
    item: pytest.Item, collector: QueryCollector, limit: int, source: str | None = None
) -> str | None:
    """The budget failure text, or None; a bug here never fails the test."""
    try:
        if collector.statement_count <= limit:
            return None
        return format_budget(
            limit,
            collector.statements,
            cwd=item.config.rootpath,
            total=collector.statement_count,
            db_time=collector.db_time,
            source=source,
        )
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "budget report")
        return None


def _record(item: pytest.Item, collector: QueryCollector, settings: _Settings) -> None:
    """Remember the test's statement count for the session report and the JSON."""
    # After an internal error the listeners stop recording, so a count would be wrong.
    if settings.mode == "off" or internal_error() is not None:
        return
    if settings.json_path is not None:
        testjson.record_counts(settings.tests, item.nodeid, collector)
    elif settings.update_budgets:
        settings.tests[item.nodeid] = {"statements": collector.statement_count}
    counts = item.config.stash.get(_report, None)
    if counts is not None:
        counts.append((item.nodeid, collector.statement_count))


def _write_report(
    terminalreporter: pytest.TerminalReporter, settings: _Settings
) -> None:
    terminalreporter.write_sep("=", "queryguard report")
    if settings.mode == "off":
        terminalreporter.write_line(
            "queryguard report: measurement is off (queryguard_mode = off)"
        )
        return
    if internal_error() is not None:
        terminalreporter.write_line(
            "queryguard report: incomplete, measurement stopped after an internal error"
        )
    elif settings.report_incomplete:
        terminalreporter.write_line(
            "queryguard report: incomplete, a pytest-xdist worker did not send "
            "its counts"
        )
    counts = terminalreporter.config.stash.get(_report, [])
    if not counts:
        terminalreporter.write_line("no tests were measured")
        return
    # Tests with equal counts by node id: the same list whatever order the
    # tests ran in (pytest-randomly) and whichever worker ran them.
    heaviest = sorted(counts, key=lambda entry: (-entry[1], entry[0]))
    for nodeid, count in heaviest[:_REPORT_SIZE]:
        terminalreporter.write_line(f"{count:>5}  {nodeid}")


def _write_index_notes(
    terminalreporter: pytest.TerminalReporter, settings: _Settings
) -> None:
    notes = terminalreporter.config.stash.get(_index_notes, None)
    found = notes is not None and bool(
        notes.notices or notes.errors or notes.partial_skipped
    )
    if not found and not settings.index_notes_incomplete:
        return
    terminalreporter.write_sep("=", "queryguard index check")
    if notes is not None and found:
        for line in format_index_notes(
            notes.notices, notes.errors, notes.first_error, notes.partial_skipped
        ):
            terminalreporter.write_line(line)
    if settings.index_notes_incomplete:
        terminalreporter.write_line(
            "incomplete: a pytest-xdist worker did not send what its index check "
            "skipped"
        )


def _write_test_code(
    terminalreporter: pytest.TerminalReporter, settings: _Settings
) -> None:
    """A section for the findings of the test code that were left out."""
    left_out = settings.test_code_left_out
    if settings.test_code != "off" or not left_out:
        return
    terminalreporter.write_sep("=", "queryguard: test code", yellow=True)
    for line in format_test_code_summary(left_out):
        terminalreporter.write_line(line)


def _write_stale_ignores(
    terminalreporter: pytest.TerminalReporter, settings: _Settings
) -> None:
    """Warn about ignores that matched no finding in this run."""
    # After an internal error or with measurement off, nothing was matched.
    if settings.mode == "off" or internal_error() is not None:
        return
    stale: list[IgnoreRule] = []
    # An ini pattern or an ignore() block in a helper may be for a test that
    # did not run (-k, a file argument, -x, Ctrl-C), so a partial run lists
    # neither. A marker belongs to its test, which ran its analysis.
    # Under pytest-xdist the workers send what they used (testnodedown).
    if not settings.run_partial and not settings.ignores_incomplete:
        stale = [rule for rule in settings.ignore if rule not in settings.ignore_used]
    markers = sorted(
        dict.fromkeys(settings.stale_markers),  # --dist each: once per worker
        key=lambda entry: (entry[0], str(entry[1]), entry[2]),
    )
    stale_blocks: list[tuple[str, str]] = []
    if not settings.run_partial and not settings.blocks_incomplete:
        stale_blocks = [
            (where, text)
            for where, text in sorted(settings.blocks_entered.items())
            if where not in settings.blocks_used
        ]
    lines = format_stale_ignores(stale, markers, stale_blocks)
    if lines:
        terminalreporter.write_sep("=", "queryguard: stale ignores", yellow=True)
        for line in lines:
            terminalreporter.write_line(line)


def _is_worker(config: pytest.Config) -> bool:
    return hasattr(config, "workerinput")


@pytest.hookimpl(optionalhook=True)
def pytest_testnodedown(node: Any, error: object) -> None:
    """pytest-xdist, on the controller: collect what a worker found."""
    try:
        settings = node.config.stash.get(_settings, None)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "merging the results of a pytest-xdist worker")
        return
    if settings is None:
        return
    output = getattr(node, "workeroutput", None) or {}
    try:
        sent = output.get("queryguard_blocks")
        if error is not None or sent is None or sent["incomplete"]:
            settings.blocks_incomplete = True
        else:
            for where, text in sent["entered"]:
                settings.blocks_entered.setdefault(where, text)
            settings.blocks_used.update(sent["used"])
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        settings.blocks_incomplete = True
        record_error(exc, "merging the results of a pytest-xdist worker")
    try:
        sent = output.get("queryguard_ignores")
        if error is not None or sent is None or sent["incomplete"]:
            settings.ignores_incomplete = True
        else:
            used = [_rule_from_wire(raw) for raw in sent["used"]]
            markers = [
                (str(nodeid), _rule_from_wire(raw), str(name))
                for nodeid, raw, name in sent["markers"]
            ]
            settings.ignore_used.update(used)
            settings.stale_markers.extend(markers)
        if output.get("queryguard_deselected", False):
            settings.deselected = True
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        settings.ignores_incomplete = True
        record_error(exc, "merging the results of a pytest-xdist worker")
    try:
        for nodeid, left_out in output.get("queryguard_test_code", ()):
            settings.test_code_left_out.setdefault(str(nodeid), int(left_out))
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "merging the test-code counts of a pytest-xdist worker")
    try:
        if (
            settings.index_check
            and settings.mode != "off"
            and (error is not None or "queryguard_index_notes" not in output)
        ):
            settings.index_notes_incomplete = True
        _merge_index_notes(node.config, output.get("queryguard_index_notes"))
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "merging the results of a pytest-xdist worker")
    counts = node.config.stash.get(_report, None)
    if counts is not None:
        try:
            sent = output.get("queryguard_report")
            if (
                error is not None
                or sent is None
                or output.get("queryguard_report_incomplete", True)
            ):
                settings.report_incomplete = True
            # with --dist each every worker runs every test: one entry per test
            known = {nodeid for nodeid, _ in counts}
            for nodeid, count in sent or []:
                if str(nodeid) not in known:
                    known.add(str(nodeid))
                    counts.append((str(nodeid), int(count)))
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            settings.report_incomplete = True
            record_error(exc, "merging the results of a pytest-xdist worker")
    if settings.counting:
        try:
            if error is not None or output.get("queryguard_json_incomplete", True):
                settings.json_incomplete = True
            testjson.merge(settings.tests, output.get("queryguard_tests", {}))
            settings.collected.update(output.get("queryguard_collected", []))
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            settings.json_incomplete = True
            record_error(exc, "merging the results of a pytest-xdist worker")
    if settings.patch_path is not None:
        try:
            if (
                error is not None
                or "queryguard_fixes" not in output
                or output.get("queryguard_fixes_incomplete", True)
            ):
                settings.fixes_incomplete = True
            for raw in output.get("queryguard_fixes", []):
                fix = fixpatch.from_wire(raw)
                if fix is not None:
                    settings.fixes[fix] = None
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            settings.fixes_incomplete = True
            record_error(exc, "merging the results of a pytest-xdist worker")
    try:
        finding_groups.merge_wire(settings.groups, output.get("queryguard_groups", []))
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "merging the results of a pytest-xdist worker")
    if not (settings.baselining or settings.sarif_path):
        return
    try:
        if error is not None or output.get("queryguard_incomplete", True):
            settings.baseline_incomplete = True
        for identity in output.get("queryguard_seen", []):
            settings.seen.add(baselines.portable(_identity(identity)))
        for file, function in output.get("queryguard_executed", []):
            settings.executed.add((file, function))
        sarif.merge_wire(settings.reported, output.get("queryguard_reported", []))
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        settings.baseline_incomplete = True
        record_error(exc, "merging the results of a pytest-xdist worker")


def _merge_index_notes(config: pytest.Config, sent: Any) -> None:
    """Add what a worker's index check could not do to the controller's notes."""
    if not sent:
        return
    notices = [str(notice) for notice in sent["notices"]]
    errors = int(sent["errors"])
    first = sent["first_error"]
    first_error = None if first is None else (str(first[0]), str(first[1]))
    skipped = [tuple(str(t) for t in tables) for tables in sent["partial_skipped"]]
    notes = config.stash.setdefault(_index_notes, _IndexNotes())
    notes.notices.update(dict.fromkeys(notices))
    notes.errors += errors
    if notes.first_error is None:
        notes.first_error = first_error
    notes.partial_skipped.extend(skipped)


def _rule_to_wire(rule: IgnoreRule) -> list[str | None]:
    return [rule.kind, rule.label, rule.file, rule.function, rule.stack]


def _rule_from_wire(raw: Any) -> IgnoreRule:
    kind, label, file, function, stack = raw
    return IgnoreRule(kind, label, file, function, stack)


def pytest_deselected(items: Sequence[pytest.Item]) -> None:
    """Remember that a filter (-k, -m, --lf, --deselect) left tests out."""
    if not items:
        return
    try:
        settings = items[0].config.stash.get(_settings, None)
        if settings is not None:
            settings.deselected = True
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "collection")


def pytest_runtest_logreport(report: pytest.TestReport) -> None:
    """For a budget update: the tests that failed keep their old entry.

    With pytest-xdist the controller gets every worker's reports here.
    """
    if not report.failed:
        return
    try:
        settings = _active[-1] if _active else None
        if settings is not None and settings.update_budgets:
            settings.failed.add(report.nodeid)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "budget update")


def pytest_collection_finish(session: pytest.Session) -> None:
    """Hook in the ORMs the collected tests imported, before any fixture runs
    (SQLAlchemy is installed only once the project has imported it)."""
    try:
        backends_ready()
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "ORM integration (after collection)")


@pytest.hookimpl(wrapper=True, tryfirst=True)
def pytest_collection_modifyitems(
    config: pytest.Config, items: list[pytest.Item]
) -> Generator[None, Any, Any]:
    """Notice a hook that drops tests without calling ``pytest_deselected``."""
    before = len(items)
    result = yield
    try:
        settings = config.stash.get(_settings, None)
        if settings is not None and len(items) < before:
            settings.deselected = True
        if settings is not None and settings.update_budgets:
            settings.collected.update(item.nodeid for item in items)
        test_code = config.stash.get(_test_code, None)
        if test_code is not None:
            test_code.add_files(_test_modules(items))
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "collection")
    return result


def _test_modules(items: Sequence[pytest.Item]) -> set[str]:
    """The files of the Python test modules of ``items`` (not doctests)."""
    files: set[str] = set()
    for item in items:
        module = item.getparent(pytest.Module)
        if module is not None and type(module).__name__ != "DoctestModule":
            files.add(str(module.path))
    return files


def _test_key(item: pytest.Item) -> tuple[str | None, str]:
    """(rootdir-relative file, function) of a test, as a finding names a call site."""
    path = Path(str(item.path))
    try:
        file: str | None = path.relative_to(item.config.rootpath).as_posix()
    except ValueError:
        file = str(path)
    return file, getattr(item, "originalname", None) or item.name


def _run_is_narrowed(config: pytest.Config, deselected: bool) -> bool:
    """True when the session did not aim at the whole suite.

    That is a deselecting filter, ``--lf``, ``--sw``, ``--pyargs``, an ``--ignore``
    given on the command line, or file and node arguments that do not cover every
    ``testpaths`` entry (or the rootdir without it).
    """
    if deselected:
        return True
    # --lf skips whole files at collection without calling pytest_deselected
    for option in ("lf", "stepwise", "pyargs"):
        if config.getoption(option, None):
            return True
    if _ignores_on_command_line(config):
        return True
    suite = _suite_paths(config)
    invocation = config.invocation_params.dir
    given = [
        Path(os.path.abspath(Path(invocation, str(arg))))
        for arg in config.args
        if "::" not in str(arg)
    ]
    # the run covers the suite when every default path is one of the
    # arguments or below one of them; a node id covers nothing
    return not all(any(arg == p or arg in p.parents for arg in given) for p in suite)


def _suite_paths(config: pytest.Config) -> list[Path]:
    """The paths a bare ``pytest`` in the rootdir collects."""
    root = config.rootpath
    found: list[Path] = []
    for entry in config.getini("testpaths") or []:
        found.extend(
            Path(os.path.abspath(Path(root, match)))
            for match in glob.glob(str(entry), root_dir=root, recursive=True)
        )
    return found or [root]


def _ignores_on_command_line(config: pytest.Config) -> bool:
    """An ``--ignore`` or ``--ignore-glob`` on the command line or in PYTEST_ADDOPTS.

    One in the ini ``addopts`` is part of how the suite is defined, like
    ``collect_ignore``, so a run with it still covers the whole suite.
    """
    tokens = [str(arg) for arg in config.invocation_params.args]
    tokens += shlex.split(os.environ.get("PYTEST_ADDOPTS", ""))
    return any(
        token in ("--ignore", "--ignore-glob")
        or token.startswith(("--ignore=", "--ignore-glob="))
        for token in tokens
    )


def _identity(raw: Any) -> Identity:
    kind, label, file, function = raw
    return (kind, label, file, function)


_ABNORMAL_EXIT = frozenset(
    (
        pytest.ExitCode.INTERRUPTED,
        pytest.ExitCode.USAGE_ERROR,
        pytest.ExitCode.INTERNAL_ERROR,
    )
)


def pytest_sessionfinish(
    session: pytest.Session, exitstatus: int | pytest.ExitCode
) -> None:
    config = session.config
    settings = config.stash.get(_settings, None)
    if settings is not None and _is_worker(config):
        try:
            output = cast(Any, config).workeroutput
            if settings.groups:
                output["queryguard_groups"] = finding_groups.to_wire(settings.groups)
            output["queryguard_blocks"] = {
                "entered": sorted(settings.blocks_entered.items()),
                "used": sorted(settings.blocks_used),
                "incomplete": internal_error() is not None,
            }
            output["queryguard_ignores"] = {
                "used": [_rule_to_wire(rule) for rule in settings.ignore_used],
                "markers": [
                    [nodeid, _rule_to_wire(rule), name]
                    for nodeid, rule, name in settings.stale_markers
                ],
                "incomplete": internal_error() is not None,
            }
            output["queryguard_deselected"] = settings.deselected
            output["queryguard_test_code"] = sorted(settings.test_code_left_out.items())
            notes = config.stash.get(_index_notes, None) or _IndexNotes()
            output["queryguard_index_notes"] = {
                "notices": list(notes.notices),
                "errors": notes.errors,
                "first_error": notes.first_error,
                "partial_skipped": [list(t) for t in notes.partial_skipped],
            }
            counts = config.stash.get(_report, None)
            if counts is not None:
                output["queryguard_report"] = [list(entry) for entry in counts]
                output["queryguard_report_incomplete"] = internal_error() is not None
            if settings.patch_path is not None:
                output["queryguard_fixes"] = [
                    fixpatch.to_wire(fix) for fix in settings.fixes
                ]
                output["queryguard_fixes_incomplete"] = internal_error() is not None
            if settings.counting:
                output["queryguard_tests"] = settings.tests
                output["queryguard_collected"] = sorted(settings.collected)
                output["queryguard_json_incomplete"] = internal_error() is not None
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            record_error(exc, "sending the results to the pytest-xdist controller")
    elif settings is not None:
        try:
            _note_partial_run(session, settings, exitstatus)
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            record_error(exc, "end of the session")
        if settings.patch_path is not None:
            _write_patch(settings)
        if settings.json_path is not None:
            _write_json(session, settings, exitstatus)
        if settings.update_budgets:
            _write_budgets(session, settings, exitstatus)
    if settings is None or not (settings.baselining or settings.sarif_path):
        return
    if _is_worker(config):
        # sent to the controller when the worker finishes
        output = cast(Any, config).workeroutput
        output["queryguard_incomplete"] = True  # until the results are in
        try:
            output["queryguard_seen"] = [
                list(identity) for identity in sorted_identities(settings.seen)
            ]
            output["queryguard_reported"] = sarif.to_wire(settings.reported)
            output["queryguard_executed"] = sorted(
                settings.executed, key=lambda key: (key[0] or "", key[1])
            )
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            record_error(exc, "sending the results to the pytest-xdist controller")
            output["queryguard_seen"] = []
            output["queryguard_reported"] = []
        output["queryguard_incomplete"] = internal_error() is not None
        return
    try:
        if internal_error() is not None:
            settings.baseline_incomplete = True
        # A collection error also counts when the run went on: pytest-xdist
        # without -x ends it with "tests failed", a serial run is interrupted.
        interrupted = settings.collection_failed or (
            exitstatus in _ABNORMAL_EXIT
            and not _xdist_maxfail_stop(session, settings, exitstatus)
        )
        if settings.update_baseline:
            _update_baseline(session, settings, interrupted)
        if settings.sarif_path is not None:
            if session.config.getoption("collectonly", False):
                # an empty report would close every alert
                settings.sarif_failed = (
                    "not written: --collect-only runs no tests; "
                    "an existing file is left as it was"
                )
            elif interrupted:
                # a partial report would close the alerts of the tests that never ran
                settings.sarif_failed = (
                    "not written: the run was interrupted or did not finish "
                    "(collection error, Ctrl-C or internal error); "
                    "an existing file is left as it was"
                )
            else:
                _write_sarif(settings)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "writing the baseline or SARIF file")


def _note_partial_run(
    session: pytest.Session, settings: _Settings, exitstatus: int | pytest.ExitCode
) -> None:
    """Note whether some selected test, or some test of the suite, did not run."""
    settings.run_stopped = bool(
        settings.collection_failed
        or exitstatus in _ABNORMAL_EXIT
        or session.shouldstop
        or session.shouldfail
    )
    settings.run_partial = (
        settings.run_stopped
        or bool(session.config.getoption("collectonly", False))
        or _run_is_narrowed(session.config, settings.deselected)
    )


def _xdist_maxfail_stop(
    session: pytest.Session, settings: _Settings, exitstatus: int | pytest.ExitCode
) -> bool:
    """A pytest-xdist run that -x or --maxfail stopped, not a real interruption.

    pytest-xdist ends such a run with the "interrupted" exit status where a
    serial run ends with "tests failed"; it is then treated as the serial run.
    A collection error under -x sets the same flags and stays an interruption.
    """
    return (
        exitstatus == pytest.ExitCode.INTERRUPTED
        and bool(session.shouldstop or session.shouldfail)
        and not settings.collection_failed
        and session.config.pluginmanager.has_plugin("dsession")
    )


def _write_sarif(settings: _Settings) -> None:
    path = settings.sarif_path
    if path is None:
        return
    try:
        version = importlib.metadata.version("pytest-queryguard")
    except importlib.metadata.PackageNotFoundError:
        version = "unknown"
    try:
        prefix = sarif.workspace_prefix(
            settings.rootpath, os.environ.get("GITHUB_WORKSPACE")
        )
        document, omitted = sarif.build(settings.reported, version, prefix)
        sarif.write(path, document)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        settings.sarif_failed = (
            f"could not write {_shown(path, settings.rootpath)}: {exc}"
        )
        return
    count = len(document["runs"][0]["results"])
    noun = "result" if count == 1 else "results"
    text = f"{_shown(path, settings.rootpath)}: {count} {noun}"
    if omitted:
        text += f" ({omitted} left out: no location inside the rootdir)"
    settings.sarif_result = text


def _write_patch(settings: _Settings) -> None:
    """Write every fix of the run as one patch, empty when there is none."""
    path = settings.patch_path
    root = settings.rootpath
    if path is None or root is None:
        return
    shown = _shown(path, root)
    try:
        text, files, changed = fixpatch.combine(settings.fixes, root, settings.started)
        atomic_write_text(path, text)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        settings.patch_failed = f"could not write {shown}: {exc}"
        return
    if files:
        noun = "file" if files == 1 else "files"
        settings.patch_result = (
            f"{shown}: changes {files} {noun}; apply it from the rootdir ({root}) "
            f"with git apply {shlex.quote(shown)}"
        )
    else:
        settings.patch_result = (
            f"{shown}: empty, no finding had a parent query line certain enough "
            "for a patch"
        )
    if changed:
        settings.patch_result += (
            f"\nleft out, modified after the session started: {', '.join(changed)}"
        )


def _counts_complete(
    session: pytest.Session, settings: _Settings, exitstatus: int | pytest.ExitCode
) -> bool:
    """Whether every selected test ran and was measured."""
    return not (
        settings.json_incomplete
        or internal_error() is not None
        or settings.collection_failed
        or exitstatus in _ABNORMAL_EXIT
        or session.shouldstop
        or session.shouldfail
    )


def _write_budgets(
    session: pytest.Session, settings: _Settings, exitstatus: int | pytest.ExitCode
) -> None:
    path = settings.budgets_path
    if path is None:
        return
    if not _counts_complete(session, settings, exitstatus):
        settings.budgets_failed = (
            "not updated: the run stopped early or measurement failed"
        )
        return
    if session.config.getoption("collectonly", False):
        settings.budgets_failed = "not updated: --collect-only runs no tests"
        return
    narrowed = _run_is_narrowed(session.config, settings.deselected)
    if narrowed and settings.budgets_previous_error is not None:
        settings.budgets_failed = (
            f"not updated: {settings.budgets_previous_error}; this run does not "
            "cover the whole suite, so the entries of the other tests would be lost"
        )
        return
    before = settings.budgets
    marked = {k for k, e in settings.tests.items() if e.get("max_queries_marker")}
    counts = {
        nodeid: count
        for nodeid, count in budget_files.counts_of(settings.tests).items()
        if nodeid not in marked and nodeid not in settings.failed
    }
    after = budget_files.updated(
        before,
        counts,
        narrowed=narrowed,
        collected=settings.collected,
        marked=marked,
    )
    try:
        budget_files.write(path, after)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        settings.budgets_failed = (
            f"could not write {_shown(path, settings.rootpath)}: {exc}"
        )
        return
    text = f"{_shown(path, settings.rootpath)}: {budget_files.describe(before, after)}"
    if settings.budgets_previous_error is not None:
        text += f"\nthe previous file was replaced: {settings.budgets_previous_error}"
    kept = len(settings.failed & set(after))
    if kept:
        noun = "failing test kept its" if kept == 1 else "failing tests kept their"
        text += f"\n{kept} {noun} previous budget"
    if narrowed:
        text += "\nthis run did not cover the whole suite: entries of tests that did not run are kept"
    settings.budgets_written = text


def _write_json(
    session: pytest.Session, settings: _Settings, exitstatus: int | pytest.ExitCode
) -> None:
    path = settings.json_path
    if path is None:
        return
    try:
        version = importlib.metadata.version("pytest-queryguard")
    except importlib.metadata.PackageNotFoundError:
        version = "unknown"
    complete = _counts_complete(session, settings, exitstatus)
    try:
        testjson.write(path, testjson.document(settings.tests, version, complete))
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        settings.json_failed = (
            f"could not write {_shown(path, settings.rootpath)}: {exc}"
        )
        return
    count = len(settings.tests)
    text = f"{_shown(path, settings.rootpath)}: {count} {'test' if count == 1 else 'tests'}"
    if not complete:
        text += " (incomplete: the run stopped early or measurement failed)"
    settings.json_result = text


def _update_baseline(
    session: pytest.Session, settings: _Settings, interrupted: bool = False
) -> None:
    path = settings.baseline_path
    if path is None:
        return
    if interrupted:
        settings.baseline_failed = (
            "not updated: the run was interrupted or did not finish "
            "(collection error, Ctrl-C or internal error)"
        )
        return
    if session.shouldstop or session.shouldfail or settings.baseline_incomplete:
        settings.baseline_failed = (
            "not updated: the run stopped early or measurement failed"
        )
        return
    if session.config.getoption("collectonly", False):
        settings.baseline_failed = "not updated: --collect-only runs no tests"
        return
    before = settings.baseline or frozenset()
    after = frozenset(settings.seen)
    narrowed = _run_is_narrowed(session.config, settings.deselected)
    kept: frozenset[Identity] = frozenset()
    if narrowed:
        # only tests that ran may replace their entries; an entry whose
        # (file, function) is no test that ran stays, whether its test was
        # left out or deleted (a full run prunes it)
        kept = frozenset(
            entry
            for entry in before - after
            if (entry[2], entry[3]) not in settings.executed
        )
        after = after | kept
    try:
        baselines.write(path, after)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        settings.baseline_failed = (
            f"could not write {_shown(path, settings.rootpath)}: {exc}"
        )
        return
    noun = "entry" if len(after) == 1 else "entries"
    text = (
        f"{_shown(path, settings.rootpath)}: {len(after)} {noun} "
        f"({len(after - before)} added, {len(before - after)} removed)"
    )
    if narrowed and kept:
        reason = "its test did not run" if len(kept) == 1 else "their tests did not run"
        noun = "entry" if len(kept) == 1 else "entries"
        text += (
            f"\nthis run did not cover the whole suite: {len(kept)} {noun} kept "
            f"because {reason}"
        )
    elif narrowed:
        text += (
            "\nthis run did not cover the whole suite, but no entry belonged to "
            "a test that did not run"
        )
    settings.baseline_written = text


def _write_baseline_summary(
    terminalreporter: pytest.TerminalReporter, settings: _Settings
) -> None:
    if not settings.baselining:
        return
    if settings.update_baseline:
        if settings.baseline_failed is not None:
            terminalreporter.write_sep("=", "queryguard: baseline", red=True)
            terminalreporter.write_line(
                f"queryguard baseline {settings.baseline_failed}"
            )
        elif settings.baseline_written is not None:
            terminalreporter.write_sep("=", "queryguard: baseline updated")
            terminalreporter.write_line(settings.baseline_written)
            if settings.baseline_previous_error is not None:
                terminalreporter.write_line(
                    f"replaced an unusable file ({settings.baseline_previous_error})"
                )
        return
    if (
        settings.mode == "off"
        or settings.baseline_incomplete
        or internal_error() is not None
        or settings.baseline_path is None
    ):
        return
    unmatched = (settings.baseline or frozenset()) - settings.seen
    if settings.run_partial:
        # only an entry of a test that ran can be told stale, as in a partial
        # update (an entry outside the tests is never)
        unmatched = frozenset(
            entry for entry in unmatched if (entry[2], entry[3]) in settings.executed
        )
    stale = baselines.sorted_identities(unmatched)
    lines = format_stale_baseline(
        stale, _shown(settings.baseline_path, settings.rootpath)
    )
    if lines:
        terminalreporter.write_sep(
            "=", "queryguard: stale baseline entries", yellow=True
        )
        for line in lines:
            terminalreporter.write_line(line)


def _write_groups(
    terminalreporter: pytest.TerminalReporter, settings: _Settings
) -> None:
    lines = finding_groups.summary_lines(settings.groups)
    if not lines:
        return
    terminalreporter.write_sep("=", "queryguard: the same finding in several tests")
    for line in lines:
        terminalreporter.write_line(line)
    terminalreporter.write_line(
        "a finding from one place in the code is fixed once for all its tests"
    )


def _write_budgets_summary(
    terminalreporter: pytest.TerminalReporter, settings: _Settings
) -> None:
    if settings.budgets_failed is not None:
        terminalreporter.write_sep("=", "queryguard: budgets", red=True)
        terminalreporter.write_line(f"queryguard budgets {settings.budgets_failed}")
    elif settings.budgets_written is not None:
        terminalreporter.write_sep("=", "queryguard: budgets updated")
        terminalreporter.write_line(settings.budgets_written)


def _write_json_summary(
    terminalreporter: pytest.TerminalReporter, settings: _Settings
) -> None:
    if settings.json_failed is not None:
        terminalreporter.write_sep("=", "queryguard: JSON", red=True)
        terminalreporter.write_line(f"queryguard JSON {settings.json_failed}")
    elif settings.json_result is not None:
        terminalreporter.write_sep("=", "queryguard: JSON written")
        terminalreporter.write_line(settings.json_result)


def _write_sarif_summary(
    terminalreporter: pytest.TerminalReporter, settings: _Settings
) -> None:
    if settings.sarif_failed is not None:
        terminalreporter.write_sep("=", "queryguard: SARIF", red=True)
        terminalreporter.write_line(f"queryguard SARIF {settings.sarif_failed}")
    elif settings.sarif_result is not None:
        terminalreporter.write_sep("=", "queryguard: SARIF written")
        terminalreporter.write_line(settings.sarif_result)
        if settings.baseline_incomplete:
            terminalreporter.write_line(
                "incomplete: measurement stopped in this process or in a "
                "pytest-xdist worker, so findings may be missing"
            )


def _write_patch_summary(
    terminalreporter: pytest.TerminalReporter, settings: _Settings
) -> None:
    if settings.patch_failed is not None:
        terminalreporter.write_sep("=", "queryguard: patch", red=True)
        terminalreporter.write_line(f"queryguard patch {settings.patch_failed}")
    elif settings.patch_result is not None:
        terminalreporter.write_sep("=", "queryguard: patch written")
        terminalreporter.write_line(settings.patch_result)
        if settings.fixes_incomplete or internal_error() is not None:
            terminalreporter.write_line(
                "incomplete: measurement stopped in this process or in a "
                "pytest-xdist worker, so fixes may be missing"
            )
        elif settings.run_stopped:
            terminalreporter.write_line(
                "incomplete: the run stopped before every test ran, so fixes "
                "may be missing"
            )


def pytest_terminal_summary(terminalreporter: pytest.TerminalReporter) -> None:
    config = terminalreporter.config
    settings = config.stash.get(_settings, None)
    if settings is None:
        # pytest_configure failed: a usage error (then nothing was recorded)
        # or a bug, which is reported here.
        _report_internal_error(config)
        try:
            _write_internal_failure(terminalreporter)
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            record_error(exc, "failure summary")
        return
    try:
        _write_index_notes(terminalreporter, settings)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "summary of the index check")
    if config.getoption("queryguard_report"):
        try:
            _write_report(terminalreporter, settings)
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            record_error(exc, "queryguard report")
    try:
        _write_groups(terminalreporter, settings)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "summary of findings in several tests")
    try:
        _write_test_code(terminalreporter, settings)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "summary of the findings in test code")
    try:
        _write_stale_ignores(terminalreporter, settings)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "stale-ignore summary")
    try:
        _write_baseline_summary(terminalreporter, settings)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "baseline summary")
    try:
        _write_sarif_summary(terminalreporter, settings)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "SARIF summary")
    try:
        _write_patch_summary(terminalreporter, settings)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "patch summary")
    try:
        _write_json_summary(terminalreporter, settings)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "JSON summary")
    try:
        _write_budgets_summary(terminalreporter, settings)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "budget summary")
    _report_internal_error(config)
    try:
        _write_internal_failure(terminalreporter)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "failure summary")


@pytest.hookimpl(wrapper=True)
def pytest_runtest_call(item: pytest.Item) -> Generator[None, Any, Any]:
    # A finding escalated by ``filterwarnings = error`` is raised from this frame;
    # keep the plugin's own source out of that failure, as in fail mode. Any other
    # exception (a user test failure, a plugin bug) keeps this frame visible.
    __tracebackhide__ = _hide_escalated_warning
    _start_fixture(item)
    settings = item.config.stash.get(_settings, None)
    if settings is None:
        # pytest_configure did not complete (for example it raised a UsageError
        # for a bad option), so there is nothing to measure with.
        return (yield)
    if settings.baselining:
        try:
            settings.executed.add(_test_key(item))
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            record_error(exc, "baseline update")
    # Marker errors fail the test on purpose (pytest.fail), before it runs.
    try:
        limit = _budget(item)
        source = None
        if limit is None:
            limit, source = _other_budget(item, settings)
        time_limit = _time_budget(item)
        route_budgets = _route_config(item, settings)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "start of the measurement")
        _report_internal_error(item.config)
        return (yield)
    _warn_deprecated_markers(item)
    if (
        settings.mode == "off"
        and limit is None
        and time_limit is None
        and route_budgets is None
    ):
        return (yield)
    index_check = settings.mode != "off" and settings.index_check
    try:
        exempt_all, exempt = _index_exemption(item) if index_check else (False, ())
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "start of the measurement")
        _report_internal_error(item.config)
        return (yield)
    # Before the collector is pushed: a bad ignore marker fails the test here
    # (pytest.fail), and would otherwise leave the collector on the stack.
    strict_hook = None
    try:
        if settings.strict and settings.mode != "off":
            strict_hook = _strict_hook(item, settings)
        collector, trackers = _start_measuring(
            settings,
            budgets=limit is not None
            or time_limit is not None
            or route_budgets is not None,
            index_check=index_check and not exempt_all,
        )
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "start of the measurement")
        _report_internal_error(item.config)
        return (yield)
    if strict_hook is not None:
        collector.strict = strict_hook
        collector.strict_threshold = settings.relationship
        collector.strict_by_scope = settings.repeat_scope == SCOPE_SESSION
        collector.strict_test_code = settings.test_code == "fail"
    strict_error: NPlusOneDetected | None = None
    # the test's own failure, after strict mode raised in it
    other_error: BaseException | None = None
    recording = blocks.record_entered(collector)
    if route_budgets is not None:
        # last before the test runs: the finally below always ends it
        try:
            routes.begin(route_budgets, settings.max_events)
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            record_error(exc, "route budgets")
            route_budgets = None
    try:
        result = yield
    except BaseException as exc:
        if isinstance(exc, NPlusOneDetected) and getattr(
            exc, "_queryguard_strict", False
        ):
            with contextlib.suppress(Exception):
                trim_to_user_code(exc)
            # raised again below, after the end-of-test analysis has recorded
            # the findings (SARIF, JSON, the summary) as for any failing N+1
            strict_error = exc
        elif collector.strict_raised and isinstance(
            exc, (Exception, pytest.fail.Exception)
        ):
            # Strict mode raised, but the test failed with another error:
            # a library caught the strict one and raised its own (Pydantic's
            # from_attributes, FastAPI's response_model), or the code
            # swallowed it and the test then failed on its own. Raised again
            # below, after the analysis has recorded the N+1.
            other_error = exc
        else:
            raise
    finally:
        with contextlib.suppress(Exception):
            blocks.stop_recording(recording)
        route_texts: list[str] = []
        if route_budgets is not None:
            try:
                route_texts = routes.end(collector, item.config.rootpath)
            except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
                record_error(exc, "route budgets")
        try:
            _stop_measuring(item, collector, settings, trackers)
            entry = settings.tests.get(item.nodeid) if settings.counting else None
            if entry is not None:
                # a test with its own marker keeps no entry in the budget file
                entry["max_queries_marker"] = limit is not None and source is None
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            record_error(exc, "end of the measurement")
            _discard(collector, trackers)
        except BaseException:
            # a signal (KeyboardInterrupt, SystemExit) goes on, but leaves
            # no collector on the stack and no tracker behind
            _discard(collector, trackers)
            raise
    stopped = strict_error is not None or other_error is not None
    if stopped:
        # The test stopped at the access (or failed after it), so what it
        # would have read later is unknown: an eager load or a column it
        # reads after the loop is not unused. The checks of what a test
        # never reads do not apply.
        trackers = _Trackers()
    budget_texts: list[str] = []
    try:
        if other_error is None:
            # a test that fails with its own error has its budgets unjudged,
            # as any failing test
            budget_texts = _budget_texts(item, collector, limit, time_limit, source)
            budget_texts.extend(route_texts)
        parts, warn_texts = _results(
            item,
            collector,
            settings,
            trackers,
            budget_texts,
            exempt,
            stopped=stopped,
        )
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "end of the measurement")
        parts, warn_texts = [], []
    _report_internal_error(item.config)
    if stopped:
        # An allow_nplusone pattern may be for a finding after the access,
        # which the test never reached: as for a test that failed on its own,
        # its patterns are not listed as stale.
        settings.stale_markers[:] = [
            entry for entry in settings.stale_markers if entry[0] != item.nodeid
        ]
    if other_error is not None:
        # The test keeps its own failure; the report goes beside it, unless
        # the error already carries the strict message (Pydantic's does).
        text = "\n\n".join(parts or warn_texts)
        if text and not _carries_strict_message(other_error):
            item.add_report_section("call", "queryguard", text)
        raise other_error
    if strict_error is not None:
        # The failure at the access replaces the report's text, the same N+1.
        # A budget the test went over before the access is gone over whatever
        # the rest would have run: it goes under the N+1, not lost with the
        # report (one it would have gone over later is unknown).
        try:
            for text in budget_texts:
                add_to_strict_error(strict_error, text)
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            record_error(exc, "budget of a test stopped by strict mode")
            _report_internal_error(item.config)
        raise strict_error
    if not parts:
        _emit_warnings(item, warn_texts)
    if parts:
        pytest.fail("\n\n".join(parts), pytrace=False)
    return result


def _carries_strict_message(error: BaseException) -> bool:
    """True when the error's text already holds a strict-mode message."""
    try:
        return "queryguard strict: " in str(error)
    except Exception:  # noqa: BLE001  # a foreign __str__ may fail
        return False


@pytest.fixture
def queryguard(
    request: pytest.FixtureRequest,
) -> Generator[QueryGuardFixture, None, None]:
    """Query budgets for blocks of a test, counting the test's own thread or task.

    ``with queryguard.max_queries(3):`` fails when the block runs more than 3
    SQL statements, ``with queryguard.num_queries(3):`` unless it runs exactly
    3; threads that were running before the block do not count.
    ``queryguard.queries`` and ``queryguard.count`` are the statements the
    test function has run so far, from every thread.
    """
    guard = QueryGuardFixture()
    stash = request.node.stash
    stash.setdefault(_guards, []).append(guard)
    if stash.get(_call_started, False):
        guard._start()  # requested from the test function itself
    yield guard
    guard._stop()  # when the test function never ran


def _fixtures(item: pytest.Item) -> list[QueryGuardFixture]:
    """The ``queryguard`` fixtures of the test, also those requested by name."""
    return item.stash.get(_guards, [])


def _start_fixture(item: pytest.Item) -> None:
    """Start the count of a requested ``queryguard`` fixture, at the test function.

    Here and not in the fixture, so that the statements of the fixtures set up
    after it are not counted. The count is process-wide, so it does not
    matter which task or thread the test function runs in.
    """
    try:
        item.stash[_call_started] = True
        for guard in _fixtures(item):
            guard._start()
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "start of the queryguard fixture")
        _report_internal_error(item.config)


@pytest.hookimpl(tryfirst=True)
def pytest_runtest_teardown(item: pytest.Item) -> None:
    """Stop the ``queryguard`` fixtures before any fixture tears down."""
    try:
        item.stash[_call_started] = False
        for guard in _fixtures(item):
            guard._stop()
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "end of the queryguard fixture")


def _hide_escalated_warning(
    excinfo: pytest.ExceptionInfo[BaseException] | None,
) -> bool:
    """Hide a plugin frame only when a ``QueryGuardWarning`` was raised as an error."""
    return excinfo is not None and (
        excinfo.errisinstance(QueryGuardWarning)
        or bool(getattr(excinfo.value, "_queryguard_strict", False))
    )


def _emit_warnings(item: pytest.Item, texts: list[str]) -> None:
    """Emit each finding as a ``QueryGuardWarning`` located at the test."""
    __tracebackhide__ = _hide_escalated_warning
    if not texts:
        return  # reportinfo() is not free: once per test, for nothing
    path, line, _ = item.reportinfo()
    for text in texts:
        std_warnings.warn_explicit(
            QueryGuardWarning(text),
            QueryGuardWarning,
            str(path),
            (line or 0) + 1,
        )


@dataclass(frozen=True, slots=True)
class _Trackers:
    """The trackers of the experimental checks that are on, for one test body."""

    eager: eager.Tracker | None = None
    columns: unused_columns.Tracker | None = None

    def stop(self) -> None:
        try:
            if self.eager is not None:
                _sqlalchemy_check("eager").stop(self.eager)
        finally:
            if self.columns is not None:
                _sqlalchemy_check("unused_columns").stop(self.columns)


def _start_trackers(settings: _Settings) -> _Trackers:
    if settings.mode == "off":
        return _Trackers()
    # the checks of SQLAlchemy that are opt-in; not imported while off
    eager = sys.modules.get("pytest_queryguard.eager")
    unused_columns = sys.modules.get("pytest_queryguard.unused_columns")
    tracker = eager.start() if eager is not None and eager.is_enabled() else None
    try:
        columns = (
            unused_columns.start()
            if unused_columns is not None and unused_columns.is_enabled()
            else None
        )
    except BaseException:
        if tracker is not None and eager is not None:
            eager.stop(tracker)
        raise
    return _Trackers(tracker, columns)


def _start_measuring(
    settings: _Settings, *, budgets: bool, index_check: bool
) -> tuple[QueryCollector, _Trackers]:
    """A collector on the stack and the trackers of the experimental checks."""
    if budgets:
        install()  # idempotent; budgets also work when the mode is off
    collector = QueryCollector()
    collector.max_events = settings.max_events
    collector.index_check = index_check
    collector.index_advisor = settings.index_advisor
    collector.hypopg = settings.hypopg
    trackers = _start_trackers(settings)
    try:
        push(collector)
    except BaseException:
        trackers.stop()
        raise
    return collector, trackers


def _stop_measuring(
    item: pytest.Item,
    collector: QueryCollector,
    settings: _Settings,
    trackers: _Trackers,
) -> None:
    """Take the collector off the stack, whatever happens; never raises an Exception.

    Runs in a finally block: an error here would replace the test's own.
    """
    try:
        try:
            trackers.stop()
        finally:
            pop(collector)
        _report_internal_error(item.config)
        _record(item, collector, settings)  # failing tests are reported too
        _note_index_check(item.config, collector)
    except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
        record_error(exc, "end of the measurement")


def _discard(collector: QueryCollector, trackers: _Trackers) -> None:
    """Best effort: take the collector and the trackers off after a failed stop."""
    # the error is already recorded; nothing here may add another
    with contextlib.suppress(Exception):
        trackers.stop()
    with contextlib.suppress(Exception):
        pop(collector)


def _results(
    item: pytest.Item,
    collector: QueryCollector,
    settings: _Settings,
    trackers: _Trackers,
    budget_texts: list[str],
    exempt: tuple[str, ...],
    *,
    stopped: bool = False,
) -> tuple[list[str], list[str]]:
    """(texts that fail the test, texts that only warn); the first wins when set.

    ``budget_texts`` are the failures of the test's budgets (``_budget_texts``);
    ``stopped``: queryguard_strict stopped the test at a lazy load.
    """
    parts = list(budget_texts)
    fail_texts: list[str] = []
    warn_texts: list[str] = []
    if settings.mode != "off":
        sieve = blocks.Sieve()
        failing, warning = _analyse(item, collector, settings, trackers, sieve)
        index = _analyse_indexes(item, collector, settings, exempt, sieve)
        try:
            kinds = _analysed_kinds(settings, collector, trackers)
            _note_blocks(item, settings, sieve, collector, kinds, stopped=stopped)
        except Exception as exc:  # noqa: BLE001  # a plugin bug must never break the user suite
            record_error(exc, "stale ignore() blocks")
        if index is not None:
            (fail_texts if settings.fails(KIND_MISSING_INDEX) else warn_texts).append(
                index
            )
        if failing is not None:
            fail_texts.insert(0, failing)
        if warning is not None:
            warn_texts.insert(0, warning)
    if parts or fail_texts:
        # one failure: budgets first, then N+1 and index findings, then the
        # findings of kinds that would only have warned
        return [*parts, *fail_texts, *warn_texts], []
    return [], warn_texts
